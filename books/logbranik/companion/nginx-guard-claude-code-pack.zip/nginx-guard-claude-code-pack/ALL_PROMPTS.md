# Nginx Guard — Claude Code: all 60 implementation prompts

# Common execution contract

Read root CLAUDE.md, the pack's CLAUDE.md, and any existing repository AGENTS.md.
Preserve unrelated changes. Application paths below are
relative to the application repository; the pack is `docs/claude-pack/`.

Before implementation, read `tracking/state.json`, `tracking/HANDOFF.md`,
`docs/ARCHITECTURE.md`, `docs/CONTRACTS.md`, `docs/NGINX_INTEGRATION.md`,
`docs/SECURITY.md` and the relevant acceptance cases in this pack. Inspect existing code;
adapt it rather than creating parallel incompatible implementations. Run one prompt at a time.

Keep the fixed stack and trust boundaries. Use only Nginx OSS-compatible directives. Request
checks stay local and in memory. Do not introduce remote per-request authorization, paid
Nginx features, unbounded queues, hidden failure bypasses, shell-based control endpoints or
unverified TLS. Defaults are monitor-only with TTL-bound exact-IP site decisions.

Implement executable code and tests appropriate to the task. Do not stop at a plan. Use test
doubles only for counterparts not built yet and label them. Run actual tests; missing tools or
infrastructure are recorded as blockers, never fabricated passes. Development work does not
authorize unrequested production changes. Use official docs for the pinned versions.

At completion save `docs/evidence/NNN.md` in the application repo with the changed behavior,
commands run, actual results, known gaps and relevant commit ID if one exists. Update the
tracker and handoff. Mark done only after the task's criteria pass. A concise final report names
the implemented outcome, checks, limitations and next prompt. Do not auto-execute the next
prompt unless the user has separately requested continuous execution.

## Claude Code session discipline

Use the individual task file rather than loading all 60 prompts. The task effort is advisory;
select it through the client's supported controls if desired, with no silent setting changes.
When a short plan helps, follow it with implementation in the same authorized session.
Update the handoff before context compaction or interruption. Read the current code on resume.
The project instruction template is CLAUDE.project-template.md. Existing AGENTS.md rules
remain relevant and must be read explicitly; do not overwrite them during migration.

---

# 000 — Repository inventory and project bootstrap

Phase: Foundation · Recommended Claude effort: **high**
Prerequisite: No prior prompt; inspect the repository first

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Inspect the current repository, CLAUDE.md and any AGENTS.md instructions, Git changes, installed tooling and deployment assumptions. Create services/control, services/agent, deploy, tests/contracts, tests/e2e and docs/evidence only where appropriate. Record the actual Nginx version/modules, operating system and direct/proxy topology if available; mark unknown facts explicitly. Merge the project instruction template, add a README and a minimal Makefile with documented future targets. Record the architecture decisions without changing the agreed stack.

## Expected deliverables

README.md; Makefile; docs/decisions/001-scope.md; merged CLAUDE.md. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Show repository inventory, preserved existing files and the proposed directory map. Run available baseline checks and record unavailable tools without claiming success. Verify the pack remains under docs/claude-pack and all paths resolve.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/000.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 000 done --evidence docs/evidence/000.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 001 — Version selection and reproducible dependencies

Phase: Foundation · Recommended Claude effort: **high**
Prerequisite: 000 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Check official compatibility documentation for currently supported Python, Go, PostgreSQL, Nginx OSS and Vector releases. Pin exact development versions and container digests where practical; lock Python dependencies including FastAPI, Pydantic, SQLAlchemy, Alembic, psycopg and cryptography. Initialize the Go module using the standard library where sufficient. Document upgrade policy and record whether auth_request and realip modules are present. Never use floating latest production tags.

## Expected deliverables

services/control/pyproject.toml; dependency lock; services/agent/go.mod; docs/versions.md. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Install from the lockfiles in a clean environment, compile a minimal Go binary and run dependency checks. Save the actual version outputs and official reference links. An inaccessible registry is a blocker, not permission to invent a version.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/001.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 001 done --evidence docs/evidence/001.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 002 — Typed contracts and golden fixtures

Phase: Foundation · Recommended Claude effort: **high**
Prerequisite: 001 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Implement Python and Go representations for event, decision, snapshot payload, envelope and acknowledgement from CONTRACTS.md. Add strict IP normalization, duplicate-key rejection where necessary, length/count limits and timestamp handling. Create shared unsigned fixtures and frozen-clock examples for IPv4, IPv6, mapped IPv6, site scopes and expiry. Define content-type and error shapes before endpoint implementation.

## Expected deliverables

services/control/app/contracts/; services/agent/internal/contracts/; tests/contracts/. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Load the same valid and invalid fixtures in both languages. Reject hostnames, zone identifiers, bad dates, oversized IDs, duplicate JSON keys and unsupported versions. Verify mapped IPv6 normalization matches Python and Go.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/002.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 002 done --evidence docs/evidence/002.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 003 — Local networks and development certificates

Phase: Foundation · Recommended Claude effort: **high**
Prerequisite: 002 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Build a Docker Compose lab with separate edge and central networks, PostgreSQL and an echo application. Add development-only CA/certificate generation for collector, dispatcher, agent and operator roles using fresh keys. Publish services only on loopback where access is needed. Model the Nginx-to-agent Unix socket using explicit volume ownership. Keep generated private material ignored and distinguish lab trust from production enrollment.

## Expected deliverables

deploy/compose/; tools/dev-pki/; .gitignore; docs/local-development.md. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Validate Compose, inspect network exposure and prove a wrong-CA client is rejected by a TLS fixture. Ensure no default certificate or password is committed. Verify Nginx can access only the intended socket directory.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/003.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 003 done --evidence docs/evidence/003.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 004 — Database schema and initial migrations

Phase: Foundation · Recommended Claude effort: **high**
Prerequisite: 003 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Create nodes, sites, node_sites, operator identities, raw events, durable processing work, dedup keys, detections, rule versions, decisions, allowlists, per-agent revision state, snapshot envelopes, deliveries and audit tables. Use Postgres inet for normalized addresses where useful and timestamptz for time. Model uniqueness, foreign keys, optimistic versions and query indexes. Separate raw retention from dedup retention and reserve a durable outbox transaction boundary.

## Expected deliverables

services/control/alembic/; services/control/app/models/; tests/integration/test_schema.py. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Apply migrations to a clean PostgreSQL instance, test uniqueness and cross-site constraints, and test a reversible development downgrade when safe. Inspect representative query plans; do not rely on SQLite for PostgreSQL semantics.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/004.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 004 done --evidence docs/evidence/004.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 005 — Build commands and test foundation

Phase: Foundation · Recommended Claude effort: **medium**
Prerequisite: 004 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Add Python lint/type/test commands, Go formatting/vet/unit/race commands, PostgreSQL integration fixtures and contract-fixture runners. Inject clocks and ID generators so later TTL/replay tests are deterministic. Provide Makefile help, narrow task targets and an initial CI skeleton that runs only implemented checks. Establish test doubles for yet-unimplemented counterparts with visible labels.

## Expected deliverables

Makefile; tests/conftest.py; services/agent/internal/testutil/; .github/workflows/ci.yml. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Run a clean build, language checks and existing tests. Verify a deliberately failing fixture is detected by the harness, then remove that temporary failure. Document which full-system gates are scheduled later.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/005.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 005 done --evidence docs/evidence/005.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 006 — Authenticated central service and role boundaries

Phase: Log ingestion · Recommended Claude effort: **xhigh**
Prerequisite: 005 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Implement FastAPI configuration, startup/shutdown, database sessions and health endpoints behind a private mTLS TLS ingress. Derive peer identity only from ingress-overwritten verified fields, and prevent direct public access to the application port. Resolve certificates to collector, agent, dispatcher or operator roles with node/site scope. Add structured request IDs and redacted logs. Enrollment stays an offline administrator action.

## Expected deliverables

services/control/app/main.py; services/control/app/security/; deploy/central-tls/. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Test missing/forged identity headers, direct-app exposure controls, wrong certificate roles, revoked identities and unknown nodes. A collector must not call operator or agent synchronization endpoints. Verify probes do not expose secrets.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/006.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 006 done --evidence docs/evidence/006.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 007 — Bounded NDJSON ingestion

Phase: Log ingestion · Recommended Claude effort: **high**
Prerequisite: 006 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Implement POST /v1/events:batch with bounded streaming decode, line and event limits, exact NDJSON framing and bounded gzip decompression. Authenticate before expensive processing. Validate each record against the certificate-derived node/site registry. Return accepted/duplicate/quarantined counts only after transaction commit. Quarantine invalid individual records with capped redacted evidence; distinguish whole-body errors from transient database failures.

## Expected deliverables

services/control/app/api/events.py; services/control/app/ingest/; tests/integration/test_ingest.py. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Send valid/mixed/empty/array/malformed/oversized batches and a compression bomb fixture. Prove limits apply to decoded bytes and a site not assigned to the collector is rejected. Simulate a database error and verify no 2xx response.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/007.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 007 done --evidence docs/evidence/007.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 008 — Deduplication and durable processing queue

Phase: Log ingestion · Recommended Claude effort: **xhigh**
Prerequisite: 007 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Atomically insert dedup identity, accepted raw events and processing work using node_id plus request_id. Compare immutable hashes on duplicate IDs and quarantine conflicting payloads without changing the original. Implement a retry-safe Postgres worker claim strategy with bounded batches and recovery. Preserve dedup records independently of raw-event retention. Never increment detector counters from the HTTP handler before durable acceptance.

## Expected deliverables

services/control/app/ingest/persistence.py; services/control/app/workers/queue.py; queue integration tests. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Retry the same batch concurrently and after a simulated lost response; it must create one logical event and one effect. Kill a worker before/after commit and show uncommitted work is recovered. Verify the conflicting-ID path produces a visible security counter.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/008.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 008 done --evidence docs/evidence/008.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 009 — Structured Nginx access logging

Phase: Log ingestion · Recommended Claude effort: **high**
Prerequisite: 008 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Adapt the reference logging configuration to the lab and existing Nginx layout. Emit server-generated request IDs, stable site IDs, resolved client IP, pre-rewrite query-free path, status, timing, bytes and Guard outcome. Keep JSON escaping enabled and auth subrequest logging disabled. Preserve existing access logs if required. Configure immediate or measured short-flush logging and document sensitive-data exclusions.

## Expected deliverables

deploy/nginx/logging.conf; tests/e2e/test_logging.py; docs/nginx-installation.md. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Run nginx -t and issue real upstream/static requests with quotes, encoded paths and internal redirects. Parse every log line as JSON and assert no query secrets, authorization, cookies or bodies are recorded. Verify one main-request event and stable original path.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/009.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 009 done --evidence docs/evidence/009.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 010 — Vector transport and disk buffering

Phase: Log ingestion · Recommended Claude effort: **high**
Prerequisite: 009 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Adapt the reference Vector file source/remap/HTTP sink to the pinned version. Normalize numeric fields and timestamps, use NDJSON with explicit framing, mTLS, a bounded disk buffer and a batch size below ingest limits. Preserve file checkpoints and expose dropped/invalid events. Provide rotation and buffer permissions. Keep identity derived from transport rather than trusting payload node identifiers.

## Expected deliverables

deploy/vector/vector.toml; collector fixture tests; docs/collector.md. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Run vector validate and a capture-server integration test that inspects real outgoing bytes, content type and certificate identity. Exercise 200, 400, 401, 413, 429 and 503 responses and document retry versus permanent failure. Restart Vector with pending buffered events.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/010.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 010 done --evidence docs/evidence/010.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 011 — First complete log ingestion demonstration

Phase: Log ingestion · Recommended Claude effort: **high**
Prerequisite: 010 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Connect real lab Nginx logs through Vector to the authenticated API and PostgreSQL. Supply a scripted demonstration with request ID correlation from HTTP request to stored row and processing state. Add collector rotation and reconnect scenarios. Measure request-finish-to-ingest delay under a modest documented load without claiming enforcement exists yet.

## Expected deliverables

tests/e2e/test_ingestion_flow.py; tools/demo-ingest.sh; docs/evidence/011.md. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Demonstrate normal traffic, temporary central outage, log rotation and collector restart. Compare sent unique request IDs with accepted/deduplicated rows, explain any limits, and save timing evidence. End-to-end tests must use actual components rather than only mocks.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/011.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 011 done --evidence docs/evidence/011.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 012 — Go agent process and local listener

Phase: Local enforcement · Recommended Claude effort: **high**
Prerequisite: 011 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Create the Go agent with strict configuration, graceful shutdown, structured logs, a local Unix HTTP listener and a separate private control listener skeleton. Set socket ownership/mode for Nginx only. Add readiness versus liveness and test-clock injection. Start unsynchronized agents as not-ready; do not silently allow from an empty accidental state. Define local-only diagnostic commands without shell execution features.

## Expected deliverables

services/agent/cmd/guard-agent/; services/agent/internal/config/; services/agent/internal/server/. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Run unit/race checks, test startup with missing directories, invalid config and occupied sockets, and verify Unix permissions. Assert visitor-accessible TCP cannot reach the check endpoint or a mutation endpoint.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/012.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 012 done --evidence docs/evidence/012.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 013 — Immutable policy state and atomic persistence

Phase: Local enforcement · Recommended Claude effort: **xhigh**
Prerequisite: 012 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Implement an immutable snapshot state indexed by scope and normalized exact IP, plus a bounded prefix matcher for manually provisioned allowlists. Persist epoch/revision/hash/signed bytes atomically with file fsync, rename and directory fsync before publication. Serialize updates and publish a complete memory view for concurrent readers. Enforce capacity and independent decision TTL limits. Use test-only injected trusted fixtures until signing is wired.

## Expected deliverables

services/agent/internal/state/; services/agent/internal/persistence/; state fault tests. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Race concurrent updates/checks; fault-inject write, fsync and rename failures; verify previous state stays usable and no success is acknowledged prematurely. Test restart from valid/truncated/tampered state and snapshot capacity boundaries.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/013.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 013 done --evidence docs/evidence/013.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 014 — Local authorization decision engine

Phase: Local enforcement · Recommended Claude effort: **high**
Prerequisite: 013 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Implement GET /v1/check on the Unix listener using validated X-Guard-IP and X-Guard-Site. Apply precedence: local bypass/emergency allowlist, central allowlist, site mode, active exact-IP bans, default allow. Return the specified outcome/revision headers and 204/403/400/503 statuses. Exclude expired entries at read time without waiting for a cleanup timer. Keep the hot path free of disk, central network and database work.

## Expected deliverables

services/agent/internal/check/; check unit tests; check benchmarks. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Test site isolation, manual global bans, allowlist precedence, monitor outcomes, unknown site, invalid IP, expiry boundaries and mapped IPv6. Use a microbenchmark only as local evidence with hardware context; run Go race tests.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/014.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 014 done --evidence docs/evidence/014.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 015 — Nginx auth_request integration

Phase: Local enforcement · Recommended Claude effort: **xhigh**
Prerequisite: 014 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Wire the protected content location to the agent Unix socket using an internal auth location, disabled recursive auth, no request body and overwritten identity headers. Implement stable site binding and a default host policy. Do not use rewrite-phase return 200 as protected test content. Audit static, regex, named and internal redirects, plus existing auth_request or satisfy directives. Keep auth caching off.

## Expected deliverables

deploy/nginx/guard-auth.conf; deploy/nginx/site-example.conf; tests/e2e/test_auth_request.py. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Run nginx -t and real allow/deny tests against an echo upstream and static file. Verify upstream never receives a denied request, method/body remain intact, internal auth URI is inaccessible externally and visitor X-Guard headers cannot change the decision.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/015.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 015 done --evidence docs/evidence/015.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 016 — Availability profiles and local emergency bypass

Phase: Local enforcement · Recommended Claude effort: **xhigh**
Prerequisite: 015 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Implement and document fail-closed as the baseline. Add an explicit optional fail-open Nginx include that maps only auth-backend 500/502/503/504 inside the internal subrequest location to a local 204 fallback. Preserve 403 blocks and existing application authentication. Add a root/operator-controlled local emergency bypass file or CLI operation, separate from central policy, with visible metrics and expiry where appropriate.

## Expected deliverables

deploy/nginx/availability/; services/agent/internal/emergency/; availability e2e tests. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Kill, hang and overload the agent; test both profiles with GET, POST bodies and application 500 responses. A real 403 must never be converted to allow. Verify bypass activation/deactivation, logging and restoration, and document residual bypass coverage.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/016.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 016 done --evidence docs/evidence/016.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 017 — Local expiry and offline enforcement milestone

Phase: Local enforcement · Recommended Claude effort: **high**
Prerequisite: 016 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Demonstrate the local request path independently of central services using explicitly test-only policy injection fixtures. Add background cleanup of expired entries while keeping read-time expiry authoritative. Validate monitor/enforce/bypass precedence, ordinary agent restart and bounded memory under repeated state replacement. Keep any fixture injection API out of production builds and make its status obvious in test configuration.

## Expected deliverables

tests/e2e/test_local_enforcement.py; agent expiry maintenance; docs/evidence/017.md. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Disconnect central network access and show local allow/block/expiry behavior still works. Restart the agent with test state, run concurrent check/update traffic and verify bounded memory plus consistent site scope. Confirm production builds expose no unauthenticated fixture-loading endpoint.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/017.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 017 done --evidence docs/evidence/017.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 018 — Ed25519 signatures and cross-language vectors

Phase: Secure synchronization · Recommended Claude effort: **xhigh**
Prerequisite: 017 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Implement the exact domain-separated byte-signing contract with Python cryptography and Go crypto/ed25519. Add bounded envelope decoding, duplicate-key rejection, pinned public-key lookup and independent semantic validation after signature verification. Generate reproducible test vectors with test-only keys. Keep production private keys outside code and outside the edge host. Do not invent custom cryptographic primitives.

## Expected deliverables

services/control/app/signing/; services/agent/internal/signature/; tests/contracts/signatures/. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Verify Python-signed bytes in Go and reject one-byte mutations, wrong keys, altered metadata, oversized envelopes, unsupported versions and duplicate payload keys. Test whitespace changes to prove verification uses signed raw bytes, not JSON reserialization.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/018.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 018 done --evidence docs/evidence/018.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 019 — Private mTLS snapshot receiver

Phase: Secure synchronization · Recommended Claude effort: **xhigh**
Prerequisite: 018 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Expose POST /v1/snapshots only on the private agent control listener with required client certificate and explicit dispatcher-role authorization. Validate signature, agent ID, pinned epoch, freshness, limits and decision scope before state application. Enforce revision replay rules and duplicate acknowledgements exactly. Persist, publish and acknowledge under serialized update handling; return a hash-bound acknowledgement.

## Expected deliverables

services/agent/internal/control/; TLS/control integration tests. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Exercise expired/wrong-role certificates, wrong agent/epoch, lower revisions, same-revision conflicting bytes, stale new payloads and idempotent repeats. Check restart preserves replay protection and disk failure cannot return an applied acknowledgement.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/019.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 019 done --evidence docs/evidence/019.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 020 — Desired decisions and transactional snapshot outbox

Phase: Secure synchronization · Recommended Claude effort: **xhigh**
Prerequisite: 019 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Implement central desired-state mutations for bans, revocations, allowlists and site modes with actor/reason and audit. In one transaction mark affected agents dirty and create durable outbox intent. Materialize bounded full snapshots from current state, allocating monotonic per-agent revisions and storing exact signed bytes atomically. Coalesce rapid mutations without losing revocations. Always recompute active TTLs; never refresh expiry just for delivery.

## Expected deliverables

services/control/app/policy/; services/control/app/outbox/; transaction integration tests. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Rollback mutations and assert neither desired state nor outbox survives alone. Race changes for one agent and verify ordered revisions. Test empty snapshots, a revoke overtaking a queued ban and repeated materialization with no accidental TTL extension.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/020.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 020 done --evidence docs/evidence/020.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 021 — Reliable push delivery and applied acknowledgements

Phase: Secure synchronization · Recommended Claude effort: **high**
Prerequisite: 020 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Implement a delivery worker with leased Postgres jobs, bounded parallelism, exponential backoff/jitter and registered destination validation. Send stored signed bytes with mTLS, do not follow arbitrary redirects, and validate agent/epoch/revision/hash acknowledgement. Classify permanent versus transient failures. Supersede expired pending envelopes by fresh higher-revision snapshots; never replay stale state after revocation. Expose desired/queued/applied separately.

## Expected deliverables

services/control/app/workers/delivery.py; delivery integration tests. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Test timeout after successful application, duplicate response delivery, wrong ack hash, wrong agent, network outage, redirection to an unapproved host and expired pending payloads. Prove retries converge without duplicate policy effects.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/021.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 021 done --evidence docs/evidence/021.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 022 — Pull reconciliation and node heartbeat

Phase: Secure synchronization · Recommended Claude effort: **high**
Prerequisite: 021 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Implement authenticated self-only snapshot polling and heartbeats. Agents reconcile every 15 seconds with jitter, using the same signature/revision pipeline as push. Return 204 for current state; regenerate expired undispatched envelopes with new revisions. Report applied revision, version, bypass, health and capacity without secrets. Detect stale agents and certificate renewal needs.

## Expected deliverables

services/control/app/api/agents.py; services/agent/internal/sync/; synchronization tests. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Drop push traffic and show pull catches up; race push/pull arrivals and prove convergence. An agent must not read another agent snapshot. Verify reconnect after a long outage does not revive expired or revoked decisions.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/022.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 022 done --evidence docs/evidence/022.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 023 — Manual block lifecycle end-to-end milestone

Phase: Secure synchronization · Recommended Claude effort: **high**
Prerequisite: 022 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Create a minimal authenticated operator API flow to ban one documentation IP on one lab site, view desired/delivery status, revoke and observe expiry. Connect all real components, including signing and mTLS. Provide a repeatable lab script with a trusted proxy fixture for synthetic source identities; never enable arbitrary X-Forwarded-For in production. Record Nginx worker identities before and after policy changes.

## Expected deliverables

tools/demo-block.sh; tests/e2e/test_manual_lifecycle.py; docs/evidence/023.md. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Show allow -> block -> revoke -> allow and a separate TTL expiry on IPv4 and IPv6. Confirm another site is unaffected and Nginx worker PIDs/start times remain stable. Capture real acknowledgement and request/log evidence with secrets redacted.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/023.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 023 done --evidence docs/evidence/023.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 024 — Event-time aggregation and concurrency correctness

Phase: Detection · Recommended Claude effort: **xhigh**
Prerequisite: 023 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Implement bounded fixed-window aggregation by site/IP/rule with freshness and future-skew limits. Use durable queue claiming plus correct transactional counter updates or serialization of shared keys across workers. Bound distinct-path storage and evidence references. Inject the clock, separate event time from received time, and retain late events for investigation while excluding them from automatic action.

## Expected deliverables

services/control/app/detection/windows.py; detection concurrency tests. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Process duplicate, out-of-order, future and delayed events across simultaneous workers. Verify counts match a reference model after crashes/retries, threshold boundaries are deterministic and no process-local counter loses state on restart.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/024.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 024 done --evidence docs/evidence/024.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 025 — Sensitive-path scanning rules

Phase: Detection · Recommended Claude effort: **high**
Prerequisite: 024 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Add versioned sensitive-path families with bounded safe matching and the initial monitor-mode threshold from DETECTION.md. Include original path normalization that does not double-decode arbitrary strings or inspect absent query/body data. Require diversity across configured families and retain a small evidence sample. Record counts, observed window and rule version with each detection.

## Expected deliverables

services/control/app/detection/rules/path_scan.py; tests/fixtures/path_scan/. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Replay labeled scanning and benign missing-file traffic, repeated requests to one path, encoded variants, long inputs and case differences. Verify match complexity remains bounded and one missing favicon cannot trigger the rule.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/025.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 025 done --evidence docs/evidence/025.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 026 — Login-abuse rule with explicit endpoint semantics

Phase: Detection · Recommended Claude effort: **high**
Prerequisite: 025 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Implement login-abuse detection only for configured site-specific login routes and declared failure status semantics. Keep it monitor-only until an operator records verified semantics. Exclude Guard-generated 403s and application errors that do not mean authentication failure. Document how an application-specific signal could later support failure responses returned as HTTP 200 without pretending access logs expose that detail.

## Expected deliverables

services/control/app/detection/rules/login_abuse.py; endpoint configuration; login fixtures. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Replay successful/failed logins, unrelated 403s, a site returning 200 on bad credentials and shared NAT traffic. Verify unconfigured routes do not contribute and blocked traffic cannot inflate failure counters.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/026.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 026 done --evidence docs/evidence/026.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 027 — Request-volume and error anomaly monitoring

Phase: Detection · Recommended Claude effort: **high**
Prerequisite: 026 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Implement monitor-only request-volume and 404-diversity detections with independent thresholds, bounded windows and site-specific baselines. Keep high volume alone from becoming an automatic ban. Add allowlist handling and a minimum observation period for recommendations. Avoid high-cardinality metric labels and never trust a claimed crawler user-agent as an exemption.

## Expected deliverables

services/control/app/detection/rules/anomalies.py; benign/abuse replay fixtures. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Replay a normal burst, shared NAT, a crawler-like pattern, deployment-related broken assets and actual path scanning. Verify only explainable monitor detections occur for ambiguous traffic and resource use stays bounded.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/027.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 027 done --evidence docs/evidence/027.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 028 — Risk policy and safe automatic decision creation

Phase: Detection · Recommended Claude effort: **xhigh**
Prerequisite: 027 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Connect eligible detections to the transactional desired-state service. Enforce monitor/enforce mode, exact site/IP scope, allowlists, TTL bounds, one active effect per rule/window and no automatic renewal in the MVP. Add revocation suppression, per-site/per-minute ban caps and a visible automatic-enforcement circuit breaker. Exclude stale events and Guard-denied traffic before the policy stage.

## Expected deliverables

services/control/app/detection/policy.py; policy safety tests. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Prove retries do not duplicate bans, a revoke is not instantly undone by old evidence, outages/backfills do not create fresh bans and circuit-breaker activation is audited. Test allowlist changes racing with decision creation.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/028.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 028 done --evidence docs/evidence/028.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 029 — Automatic detection-to-block demonstration

Phase: Detection · Recommended Claude effort: **high**
Prerequisite: 028 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Build an end-to-end lab scenario using enough controlled requests to trigger the tuned sensitive-path rule. Correlate request IDs, detector window, decision, outbox, signed revision, agent acknowledgement and denied follow-up request. Include a benign replay scenario and a delayed backlog scenario. Make the demo reset only isolated test state, never arbitrary deployments.

## Expected deliverables

tools/demo-detection.sh; tests/e2e/test_auto_block.py; docs/evidence/029.md. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Measure each pipeline stage and threshold-to-applied duration at a documented input rate. Verify subsequent requests are blocked without reload, expire/revoke correctly, and never claim the already-completed triggering request was prevented.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/029.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 029 done --evidence docs/evidence/029.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 030 — Operator roles and complete audit trail

Phase: Operations controls · Recommended Claude effort: **high**
Prerequisite: 029 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Complete viewer/operator/administrator authorization across read and write APIs using separately provisioned mTLS identities. Add consistent audit events for manual bans, revokes, allowlist/mode changes, enrollment, credential changes and emergency synchronization. Record before/after versions and reasons. Keep read-only endpoints bounded and redact sensitive evidence.

## Expected deliverables

services/control/app/operators/; services/control/app/audit/; RBAC matrix tests. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Run a role/endpoint matrix including scope violations, anonymous calls and duplicate idempotency keys. Verify audit writes commit with their mutations and explain that database-admin tampering is outside append-only table guarantees.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/030.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 030 done --evidence docs/evidence/030.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 031 — Operator CLI for investigation

Phase: Operations controls · Recommended Claude effort: **medium**
Prerequisite: 030 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Add guardctl in Go with nodes, sites, events, detections, decisions, deliveries and audit read commands. Load CA/certificate/key paths from protected config, support bounded pagination and stable JSON output, and render clear desired versus applied state. Do not print private key material or raw tokens. Add time/site/IP filters without introducing unbounded database queries.

## Expected deliverables

services/agent/cmd/guardctl/; services/agent/internal/client/; CLI tests. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Test CLI output/exit codes against a fixture API, wrong TLS identity, pagination and unavailable central service. Verify JSON output is machine-readable and terminal output safely escapes control characters from evidence.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/031.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 031 done --evidence docs/evidence/031.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 032 — Operator CLI for bounded policy changes

Phase: Operations controls · Recommended Claude effort: **high**
Prerequisite: 031 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Add explicit ban, revoke, allowlist and site-mode commands with mandatory scope, reason and TTL where relevant. Provide a dry-run that shows the concrete target and affected nodes. Use idempotency keys and optimistic versions. Make fleet/global scope an explicit flag, never the default. Show queued/applied/failed states and support a bounded wait for agent acknowledgement.

## Expected deliverables

guardctl policy commands; tests/cli/test_policy_commands/; docs/operator-cli.md. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Test accidental missing scope, expired TTL, global flag, conflict, repeated invocation and timeout waiting for one offline node. A central mutation response must not be displayed as applied everywhere.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/032.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 032 done --evidence docs/evidence/032.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 033 — Allowlist precedence and revocation race handling

Phase: Operations controls · Recommended Claude effort: **xhigh**
Prerequisite: 032 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Implement site/global manual central allowlists, exact IP and bounded CIDR entries, expiry and local emergency precedence. Recompute snapshots when allowlists change and preserve local controls outside remote snapshots. Ensure revocation suppression and detector decisions observe the newest policy under concurrency. Explain a decision that exists but is overridden by an allowlist.

## Expected deliverables

policy precedence logic; concurrency fixtures; docs/policy-precedence.md. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Race detector updates with allowlist insert/delete and revoke operations. Test IPv6 prefixes, overlapping scopes and expired allowlists. Verify a delayed signed snapshot cannot undo a newer revoke or local emergency bypass.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/033.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 033 done --evidence docs/evidence/033.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 034 — Evidence search and decision explanations

Phase: Operations controls · Recommended Claude effort: **medium**
Prerequisite: 033 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Add bounded query APIs/CLI for a decision timeline including rule version, window counts, evidence IDs, scope, original expiry, suppression, allowlist override and delivery acknowledgements. Use indexed filters and cursor pagination. Retain compact explanation summaries after raw-event retention expires. Escape hostile paths in all terminal/HTML output if any UI is added.

## Expected deliverables

services/control/app/api/investigation.py; guardctl explain; timeline integration tests. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Investigate a known lab detection from CLI and verify every timeline reference resolves or reports retention expiry honestly. Exercise pagination stability and hostile control characters without terminal injection.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/034.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 034 done --evidence docs/evidence/034.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 035 — False-positive recovery and emergency drills

Phase: Operations controls · Recommended Claude effort: **high**
Prerequisite: 034 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Write and execute the false-positive and agent-outage runbooks using guardctl and the local bypass mechanism. Revoke one ban, apply a narrow expiring allowlist when justified, verify acknowledgements and test restoration of normal enforcement. Add circuit-breaker inspection/reset commands with actor and reason. Do not delete all policy state as a shortcut.

## Expected deliverables

docs/runbooks/false-positive.md; docs/runbooks/agent-outage.md; drill evidence. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Demonstrate recovery while one agent is disconnected and distinguish its stale status from applied nodes. Confirm allowlist expiry and bypass removal behave predictably, and preserve an audit trail plus a short incident report.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/035.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 035 done --evidence docs/evidence/035.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 036 — Fleet membership and multiple sites per node

Phase: Fleet and observability · Recommended Claude effort: **high**
Prerequisite: 035 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Extend lab to at least two edge nodes and two sites with explicit node/site/agent enrollment and certificate role mapping. Create only the appropriate per-agent snapshot view and destination. Handle site addition/removal and node decommission with explicit cleanup/revocation semantics. Verify collector identity is node-scoped and agent identity is self-scoped.

## Expected deliverables

fleet registry APIs/CLI; deploy/compose/fleet profile; fleet e2e tests. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Block an IP for a shared site on both nodes, then for a site on one node only. Test unauthorized site logs, unknown host routing, removed sites and decommissioned certificates. Verify delivery to an unrelated node is impossible.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/036.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 036 done --evidence docs/evidence/036.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 037 — Snapshot coalescing and bounded delivery scaling

Phase: Fleet and observability · Recommended Claude effort: **high**
Prerequisite: 036 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Measure and improve full-snapshot fanout using dirty-agent coalescing, per-agent serialization, bounded global concurrency and latest-state supersession. Enforce 8 MiB/decision-count caps before signing and report capacity failures visibly. Prevent one offline node from blocking others. Preserve ordered desired-state semantics and do not add deltas without a new explicit protocol decision.

## Expected deliverables

outbox scheduling refinements; tests/load/snapshot_fanout/; capacity report. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Generate rapid mixed ban/revoke updates across several agents, including one offline and one slow receiver. Show convergence to latest desired state, stable memory use and no acknowledgement of an oversized or partially applied snapshot.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/037.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 037 done --evidence docs/evidence/037.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 038 — Raw-event retention and database maintenance

Phase: Fleet and observability · Recommended Claude effort: **high**
Prerequisite: 037 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Implement configurable raw, quarantine, aggregate, dedup and audit retention from OPERATIONS.md with bounded maintenance jobs. Introduce partitioning only if measured volume justifies it, preserving node/request uniqueness separately. Preserve compact decision explanations and pending work. Add disk/WAL growth monitoring and an administrative retention dry-run.

## Expected deliverables

services/control/app/workers/retention.py; retention tests; docs/storage-sizing.md. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Advance a test clock and prune eligible data without removing active decisions, pending jobs or required dedup keys. Retry events near/beyond retention limits and show old data cannot create fresh bans. Measure database storage per event.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/038.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 038 done --evidence docs/evidence/038.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 039 — Metrics and structured cross-service diagnostics

Phase: Fleet and observability · Recommended Claude effort: **high**
Prerequisite: 038 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Expose authenticated/private metrics for ingest lag, invalid/duplicate/drop counts, queue age, detector latency, decisions, delivery failures, applied revision staleness, local auth latency, bypass/unavailable state, state capacity and certificate expiry. Use bounded labels without IP/path/request-ID cardinality. Correlate structured logs with IDs while keeping sensitive material out. Add basic scrape configuration.

## Expected deliverables

services/control/app/metrics.py; services/agent/internal/metrics/; deploy/monitoring/. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Trigger representative failures and assert metrics change with bounded label sets. Verify per-request logs are sampled or bounded as configured and a full incident can be followed without exposing secrets.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/039.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 039 done --evidence docs/evidence/039.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 040 — Alert rules and operational health views

Phase: Fleet and observability · Recommended Claude effort: **medium**
Prerequisite: 039 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Provide Prometheus-compatible alert rules for stalled ingestion, collector buffer pressure, stale agents, unapplied revisions, certificate expiry, circuit breaker, bypass and auth failures. Add a small dashboard definition or CLI status summary as appropriate; avoid a separate frontend dependency. Define actionable runbook links and distinguish central outage from local enforcement failure.

## Expected deliverables

deploy/monitoring/alerts.yml; dashboard/status configuration; alert tests. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Use synthetic metric fixtures or promtool where available to test alert firing and recovery. Ensure no alert rule uses unbounded labels or mistakes monitor mode for a broken installation.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/040.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 040 done --evidence docs/evidence/040.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 041 — Measured throughput and latency baseline

Phase: Fleet and observability · Recommended Claude effort: **high**
Prerequisite: 040 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Run a repeatable load experiment with documented hardware, versions and configuration. Measure local auth latency at 1,000 requests/s and the whole pipeline at 100 completed log events/s, including storage footprint and CPU/RAM. Compare to provisional acceptance targets, identify bottlenecks and tune bounded batching/timeouts if justified. Preserve fail semantics during tuning.

## Expected deliverables

tests/load/; tools/benchmark/; docs/benchmarks/baseline.md. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Save actual p50/p95/p99, errors, backlog, threshold-to-applied duration and methodology. If targets fail, record the result and supported capacity instead of fabricating success. Rerun only the affected experiment after a substantive change.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/041.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 041 done --evidence docs/evidence/041.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 042 — Central outages, backpressure and collector recovery

Phase: Failure validation · Recommended Claude effort: **high**
Prerequisite: 041 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Exercise a sustained central outage with active local bans, new traffic, Vector buffering, rotating log files and bounded storage. Bring central back and drain replay while preventing stale evidence from generating fresh bans. Test ingest overload and permanent request errors. Document maximum supported outage from measured disk and retention settings.

## Expected deliverables

tests/chaos/test_central_outage.py; collector recovery report. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Track unique request IDs through restart/recovery, report any unavoidable loss bounds, verify original ban expiry, and ensure local auth does not call central while offline. Confirm buffer/disk/lag alerts fire before exhaustion.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/042.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 042 done --evidence docs/evidence/042.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 043 — Clock, TTL and restart fault matrix

Phase: Failure validation · Recommended Claude effort: **xhigh**
Prerequisite: 042 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Implement clock-health handling, monotonic deadlines while running and restart behavior for saved states. Simulate forward/backward wall-clock movement, invalid startup time, expiry during downtime and corrupt persisted snapshots. Ensure delivery freshness and individual ban expiry remain separate concepts. Document unavailable-state behavior when trustworthy time cannot be established.

## Expected deliverables

agent/control clock handling; tests/chaos/test_time_and_restart/. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Use injected clocks plus process restart tests to show no ban is silently extended. Verify stale delivery cannot be newly applied, already-applied valid saved decisions survive ordinary restart, and invalid time is visible under both Nginx availability profiles.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/043.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 043 done --evidence docs/evidence/043.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 044 — TLS and signing-key lifecycle

Phase: Failure validation · Recommended Claude effort: **xhigh**
Prerequisite: 043 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Implement operational certificate renewal, peer revocation and signing-key overlap rotation. Provision new verification keys separately, re-sign current state with newer revisions, then retire old trust after confirming nodes. Handle saved snapshots signed by retired keys with an explicit recovery procedure. Avoid dynamically trusting a key delivered inside an unverified control message.

## Expected deliverables

tools/pki/; docs/runbooks/key-rotation.md; security lifecycle tests. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Test expired certs, wrong SAN/role, revoked peer, overlapping keys, retired keys and an offline agent returning after rotation. Verify production key files have appropriate ownership and do not appear in archives, logs or evidence.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/044.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 044 done --evidence docs/evidence/044.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 045 — Hostile inputs and cross-scope security tests

Phase: Failure validation · Recommended Claude effort: **xhigh**
Prerequisite: 044 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Build a security regression suite for forged forwarding/Guard headers, cross-site logs, Host alias confusion, NDJSON parser boundaries, gzip limits, signature mutation, replay and callback destination abuse. Fuzz bounded Go/Python parsers where practical. Review control and query endpoints for excessive resource use and authorization gaps. Keep testing confined to the lab.

## Expected deliverables

tests/security/; Go fuzz targets; docs/security-review.md. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Run the role/identity/replay matrix and bounded fuzz campaigns with recorded seeds. Demonstrate that a collector can submit only its own authorized site logs and cannot mutate policy, read another node state or select an arbitrary dispatch target.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/045.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 045 done --evidence docs/evidence/045.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 046 — Nginx routing and existing-auth regression suite

Phase: Failure validation · Recommended Claude effort: **xhigh**
Prerequisite: 045 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Create representative Nginx fixtures for static content, reverse proxy, regex locations, try_files/named redirects, existing external authentication, health/ACME exceptions and CDN/ALB-style trusted ingress. Implement composition only where required and document unsupported integration cases. Audit satisfy and rewrite-return shortcuts. Verify resolved client IP consistently matches the log and check.

## Expected deliverables

tests/nginx-fixtures/; tests/e2e/test_routing_matrix.py; integration compatibility report. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Run allow/block tests across every fixture using actual Nginx. A site already requiring login must still require login during Guard fail-open. Verify forged direct X-Forwarded-For is ineffective and IP bans apply on both IPv4 and IPv6 protected routes.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/046.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 046 done --evidence docs/evidence/046.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 047 — Complete reliability regression gate

Phase: Failure validation · Recommended Claude effort: **high**
Prerequisite: 046 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Combine the implemented tests into a reproducible full-stack gate covering manual/automatic ban, revoke, TTL, restart, push/pull races, stale backlog, multi-site isolation and no-reload proof. Replace temporary counterpart mocks with real components on core paths. Produce a traceable pass/fail matrix against ACCEPTANCE.md and fix release-blocking findings.

## Expected deliverables

tests/e2e/full_gate/; docs/release/acceptance-matrix.md. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Run the full gate from a clean local environment and store actual outputs. Clearly list skipped checks with reasons and keep the milestone blocked if a required production invariant is unverified.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/047.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 047 done --evidence docs/evidence/047.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 048 — Production images and agent release binaries

Phase: Deployment · Recommended Claude effort: **high**
Prerequisite: 047 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Build minimal pinned central images with non-root users and a separately invokable API/detector/delivery process. Produce Linux amd64/arm64 Go agent/CLI binaries with version metadata and checksums. Include a license/dependency inventory and SBOM where tooling permits. Exclude local test keys, raw logs and development data.

## Expected deliverables

services/control/Dockerfile; tools/release/; release manifest; SBOM. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Run image startup/health checks, scan dependency/image findings with triage, and verify binaries on supported architectures via execution or clearly documented cross-build limitations. Confirm artifacts contain no generated private keys.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/048.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 048 done --evidence docs/evidence/048.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 049 — Hardened systemd units and filesystem ownership

Phase: Deployment · Recommended Claude effort: **high**
Prerequisite: 048 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Create agent and optional central worker systemd units using least privilege, explicit state/runtime directories, restart policies and bounded resources. Configure Unix socket group sharing with Nginx and log-read access for Vector. Keep writable paths narrow; do not add CAP_NET_ADMIN, Docker socket access or Nginx reload permissions. Provide environment/credential file handling.

## Expected deliverables

deploy/systemd/; deploy/tmpfiles/; docs/permissions.md. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Validate unit syntax, run the agent under intended permissions and confirm Nginx can check while unrelated local users cannot mutate state. Test service restart and read-only filesystem restrictions without breaking state persistence.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/049.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 049 done --evidence docs/evidence/049.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 050 — Idempotent installation and canary configuration

Phase: Deployment · Recommended Claude effort: **high**
Prerequisite: 049 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Provide an Ansible role or idempotent installation scripts for the two-host baseline, selecting one documented approach. Parameterize addresses, site registry, cert paths, ports and modes. Preserve existing Nginx configuration and create backups before managed include changes. Require nginx -t before the initial graceful reload and keep new sites monitor-only. Never change production through the pack-generation environment.

## Expected deliverables

deploy/ansible/ or deploy/install/; docs/installation.md; installer tests. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Run install twice on a disposable lab and show the second run makes no unintended changes. Test invalid Nginx config rollback, missing credentials, socket ownership and successful empty-snapshot bootstrap.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/050.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 050 done --evidence docs/evidence/050.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 051 — Database backup and tested restore

Phase: Deployment · Recommended Claude effort: **xhigh**
Prerequisite: 050 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Implement documented encrypted/permission-controlled PostgreSQL backup and restoration commands using the deployment platform facilities. Restore into an isolated instance and verify event/policy/audit consistency. Address per-agent revision high-water marks after a stale restore before reconnecting the fleet. Provide operator-assisted recovery or explicit epoch re-enrollment; never auto-trust a changed epoch.

## Expected deliverables

docs/runbooks/backup-restore.md; tools/backup/; restore integration evidence. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Restore a backup older than a later applied/revoked decision and prove the agent rejects rollback. Demonstrate the chosen reconciliation recovery and record restore duration, data-loss window and verification results.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/051.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 051 done --evidence docs/evidence/051.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 052 — Upgrade, rollback and compatibility procedures

Phase: Deployment · Recommended Claude effort: **high**
Prerequisite: 051 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Define rolling upgrade order for central, agent and Nginx/Vector configuration, including schema compatibility windows and contract-version negotiation. Build a rollback procedure preserving desired state, agent snapshots and audit history. For a breaking epoch/protocol change, require explicit migration rather than guessing compatibility. Document separate initial config reload versus routine policy updates.

## Expected deliverables

docs/runbooks/upgrade.md; docs/runbooks/rollback.md; compatibility tests. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Exercise an upgrade and rollback in the two-node lab with one older agent, in-flight delivery and active TTL bans. Verify unsupported versions fail visibly, requests follow configured availability policy and no expired/revoked ban reappears.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/052.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 052 done --evidence docs/evidence/052.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 053 — Deployment observability and recovery handbook

Phase: Deployment · Recommended Claude effort: **medium**
Prerequisite: 052 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Consolidate installation, topology/trusted-proxy settings, capacity, metrics, false-positive recovery, emergency bypass, cert rotation, storage pressure, central outage, agent outage and disaster recovery into an operator handbook. Include exact commands validated in the lab and how to inspect desired versus applied state. Keep secrets and private topology examples out of public documentation.

## Expected deliverables

docs/operator-handbook.md; docs/runbooks/index.md; documentation checks. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Follow the handbook from a clean lab as an operator and fix missing steps. Verify every referenced command/file exists and critical failure scenarios link to the corresponding evidence and alert.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/053.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 053 done --evidence docs/evidence/053.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 054 — Continuous integration and release policy

Phase: Release · Recommended Claude effort: **high**
Prerequisite: 053 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Finish CI with locked dependency installation, Python/Go checks, PostgreSQL integration, contracts, real Nginx/Vector validation and core end-to-end tests. Add protected release workflow, checksums and artifact retention. Keep performance/chaos jobs scheduled or opt-in when expensive but required before releases. Restrict workflow permissions and prevent untrusted PRs from receiving deployment secrets.

## Expected deliverables

.github/workflows/; release policy; CI execution evidence. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Run CI on a branch and demonstrate failures block release. Verify pull-request and trusted-release permissions differ, artifact checksums validate and the workflow does not automatically deploy to production from arbitrary code.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/054.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 054 done --evidence docs/evidence/054.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 055 — Replay evaluation and production threshold calibration

Phase: Release · Recommended Claude effort: **high**
Prerequisite: 054 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Build an offline replay command that uses the same detection code against labeled or redacted representative logs with actions disabled. Report candidate bans, benign collisions, counts by rule/site and late-event handling. Tune thresholds per site based on evidence; keep login/volume/error rules monitor-only without verified semantics. Store rule versions and an operator-reviewed calibration record.

## Expected deliverables

tools/replay/; docs/release/calibration.md; versioned rule defaults. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Run the supplied synthetic dataset and any authorized representative dataset available. Show false-positive cases and their effect on tuning; do not manufacture a production accuracy figure or silently label unknown traffic as malicious.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/055.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 055 done --evidence docs/evidence/055.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 056 — Monitor-only installation readiness

Phase: Release · Recommended Claude effort: **high**
Prerequisite: 055 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Prepare the first real-environment rollout package from observed topology, actual versions and intended sites. Validate private connectivity, mTLS enrollment, proxy trust, Nginx location coverage, storage budget, backups and operator recovery access. Supply a concrete monitor-only deployment diff and commands. If infrastructure access is unavailable, complete a reproducible lab rehearsal and mark real deployment pending.

## Expected deliverables

docs/release/readiness.md; environment inventory template; monitor rollout evidence. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Confirm logs arrive, identities match, snapshots synchronize and would-block outcomes are visible without denying visitors. Save readiness evidence or an exact unresolved-input list; never claim a deployment that was not performed.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/056.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 056 done --evidence docs/evidence/056.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 057 — Single-site enforcement canary

Phase: Release · Recommended Claude effort: **high**
Prerequisite: 056 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

For an authorized target with monitor evidence, enable one calibrated high-confidence rule on one site with short bounded TTLs and a preconfigured rollback. Observe auth latency, errors, new-ban rate, false positives and applied revisions. Keep every other site in its prior mode. If production execution is outside current authorization/access, deliver the exact reviewed canary change and exercise it in the lab.

## Expected deliverables

docs/release/canary.md; canary commands/change manifest; observed results. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Verify an isolated controlled probe is blocked, normal paths work, revoke/expiry restore access and no Nginx reload occurs. Record canary duration and observed metrics; unmet acceptance gates prevent broader enforcement.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/057.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 057 done --evidence docs/evidence/057.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 058 — Staged fleet enablement and rollback drill

Phase: Release · Recommended Claude effort: **high**
Prerequisite: 057 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Prepare and, where authorized, execute staged site/node enablement with explicit batches, dwell criteria and automatic-enforcement circuit-breaker thresholds. Verify each agent applies the intended revision before expanding. Keep rollback commands ready for mode changes/revocation and test an offline node rejoining. Do not interpret missing acknowledgements as success.

## Expected deliverables

docs/release/fleet-rollout.md; fleet status/report tooling; rollback evidence. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Run the staged process across the lab fleet and document any real-environment execution separately. Trigger rollback, confirm affected site modes and revisions, and verify the system converges when a delayed node returns.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/058.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 058 done --evidence docs/evidence/058.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.

---

# 059 — Final audit and release handoff

Phase: Release · Recommended Claude effort: **xhigh**
Prerequisite: 058 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Review the implemented repository against every requirement and acceptance invariant. Run remaining required release checks, inspect secrets/dependency findings, verify all documentation and compile a release manifest with versions, checksums, supported topology, measured capacity and known limits. Separate completed implementation, tested lab behavior and actual production deployment. Resolve blockers or explicitly leave release status blocked.

## Expected deliverables

docs/release/FINAL_REPORT.md; release manifest; final acceptance matrix; operator handoff. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Produce a requirement-to-evidence matrix, a fresh-install demonstration and a concise operator handoff. Confirm all 60 tracker rows are truthful, no mandatory test is silently skipped and production-ready language matches the evidence.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/059.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 059 done --evidence docs/evidence/059.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
