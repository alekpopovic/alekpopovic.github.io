# Run a bounded phase sequentially

Before sending, replace END_ID with one phase endpoint: 005, 011, 017, 023, 029,
035, 041, 047, 053 or 059. Do not run this template with END_ID still unresolved.

Execute from the first incomplete task through END_ID, inclusive, in `docs/claude-pack/`.
Read CLAUDE.md, state, handoff, current Git status and each individual prompt in order.
For each task: implement, run acceptance checks, save evidence, mark the truthful status and
update the handoff before moving on. Keep one writer and sequential dependency order.

Stop at the specified endpoint, a genuine blocking dependency or a client permission boundary.
Never skip a failed check to reach the endpoint. Before a context limit, save a checkpoint
with the next exact action, unfinished edits and test results. This phase instruction covers
local implementation only; do not infer authorization to deploy to an unspecified live target.
