# Nginx Guard — Claude Code paket

Claude izdanje 1.1.0 · 10. oktobar 2026. · **60 promptova, 000–059**.

Paket je prilagođen radu u Claude Code: projektna pravila u `CLAUDE.md`, kratki početni
prompt, izvršavanje po zadatku ili fazi, nastavak posle prekida i Python tracker.
Ovo je paket za izradu aplikacije, a ne već implementirana ili produkciono testirana aplikacija.

## Stack i rezultat

| Komponenta | Tehnologija |
|---|---|
| Web server | Običan Nginx Open Source + auth_request |
| Log collector | Vector, JSON, disk buffer, HTTPS/mTLS |
| Centralna aplikacija | FastAPI + PostgreSQL |
| Obrada i isporuka odluka | Python worker procesi i PostgreSQL red poslova |
| Lokalni agent | Go, memorijska lista i potpisano sačuvano stanje |
| Administracija | API i Go CLI |
| Razvoj / produkcija | Docker Compose lab / dve Linux mašine i systemd |

Na kraju implementacije sistem šalje logove centrali, prepoznaje rizično ponašanje i
primenjuje privremene IP blokade lokalno, bez reload-a za svaku blokadu. Uključeni su
allowlist, opoziv, istek, potpisane poruke, audit, monitor režim i oporavak posle prekida.

## Najbrži početak

Potreban je Python 3.11+ za sve pomoćne alate i instaliran Claude Code.
Iz raspakovanog paketa pokreni, sa stvarnom putanjom svog repozitorijuma:

```bash
python3 tools/install_pack.py --repo /putanja/do/nginx-guard-repo --dry-run
python3 tools/install_pack.py --repo /putanja/do/nginx-guard-repo
```

Installer kopira paket u `docs/claude-pack/` i dodaje njegov import u korenski
`CLAUDE.md`. Postojeći sadržaj zadržava i pravi rezervnu kopiju pre dopune.
Ako je paket već instaliran, ne prepisuje ga. Ne menja Claude dozvole ili korisnička podešavanja.

Zatim otvori Claude Code iz korena repozitorijuma i pošalji:

```text
Pročitaj docs/claude-pack/BOOTSTRAP_PROMPT.md i izvrši prvi nezavršeni prompt.
```

Ručno postavljanje je opisano u `START_HERE.md`. Za sledeći zadatak koristi
`RUN_NEXT_PROMPT.md`; za prekinutu sesiju `RESUME_PROMPT.md`.

## Praćenje rada

```bash
python3 docs/claude-pack/tools/track.py next
python3 docs/claude-pack/tools/track.py show 000
python3 docs/claude-pack/tools/track.py status
```

Ako već imaš napredak iz prethodnog izdanja, pogledaj `docs/MIGRATION.md`.
Brojevi i tehnički ciljevi zadataka su sačuvani; ne treba ponavljati završene zadatke.

Promptovi i tehničke specifikacije su na engleskom. `medium`, `high` i `xhigh` su
preporuke za Claude effort; proveri dostupne nivoe za izabrani model. Tracker ih samo
prikazuje, ne menja podešavanja. Detalji su u `docs/CLAUDE_CODE_GUIDE.md`.

Access log nastaje po završetku zahteva. Sistem blokira naredne zahteve; vremenski ciljevi
u dokumentaciji zahtevaju merenje. Početna instalacija Nginx konfiguracije zahteva test i
reload. Provere stvarnih servisa su zadaci u paketu, a ne već izvršeni rezultati.
