# 004 — Database schema and initial migrations

Phase: Foundation · Recommended Claude effort: **high**
Prerequisite: 003 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Create nodes, sites, node_sites, operator identities, raw events, durable processing work, dedup keys, detections, rule versions, decisions, allowlists, per-agent revision state, snapshot envelopes, deliveries and audit tables. Use Postgres inet for normalized addresses where useful and timestamptz for time. Model uniqueness, foreign keys, optimistic versions and query indexes. Separate raw retention from dedup retention and reserve a durable outbox transaction boundary.

## Expected deliverables

services/control/alembic/; services/control/app/models/; tests/integration/test_schema.py. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Apply migrations to a clean PostgreSQL instance, test uniqueness and cross-site constraints, and test a reversible development downgrade when safe. Inspect representative query plans; do not rely on SQLite for PostgreSQL semantics.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/004.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 004 done --evidence docs/evidence/004.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
