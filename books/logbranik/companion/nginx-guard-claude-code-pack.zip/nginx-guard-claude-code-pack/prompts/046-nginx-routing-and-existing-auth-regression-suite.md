# 046 — Nginx routing and existing-auth regression suite

Phase: Failure validation · Recommended Claude effort: **xhigh**
Prerequisite: 045 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Create representative Nginx fixtures for static content, reverse proxy, regex locations, try_files/named redirects, existing external authentication, health/ACME exceptions and CDN/ALB-style trusted ingress. Implement composition only where required and document unsupported integration cases. Audit satisfy and rewrite-return shortcuts. Verify resolved client IP consistently matches the log and check.

## Expected deliverables

tests/nginx-fixtures/; tests/e2e/test_routing_matrix.py; integration compatibility report. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Run allow/block tests across every fixture using actual Nginx. A site already requiring login must still require login during Guard fail-open. Verify forged direct X-Forwarded-For is ineffective and IP bans apply on both IPv4 and IPv6 protected routes.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/046.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 046 done --evidence docs/evidence/046.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
