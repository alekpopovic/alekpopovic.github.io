# 058 — Staged fleet enablement and rollback drill

Phase: Release · Recommended Claude effort: **high**
Prerequisite: 057 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Prepare and, where authorized, execute staged site/node enablement with explicit batches, dwell criteria and automatic-enforcement circuit-breaker thresholds. Verify each agent applies the intended revision before expanding. Keep rollback commands ready for mode changes/revocation and test an offline node rejoining. Do not interpret missing acknowledgements as success.

## Expected deliverables

docs/release/fleet-rollout.md; fleet status/report tooling; rollback evidence. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Run the staged process across the lab fleet and document any real-environment execution separately. Trigger rollback, confirm affected site modes and revisions, and verify the system converges when a delayed node returns.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/058.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 058 done --evidence docs/evidence/058.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
