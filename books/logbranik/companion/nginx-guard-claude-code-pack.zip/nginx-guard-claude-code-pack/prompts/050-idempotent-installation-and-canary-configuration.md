# 050 — Idempotent installation and canary configuration

Phase: Deployment · Recommended Claude effort: **high**
Prerequisite: 049 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Provide an Ansible role or idempotent installation scripts for the two-host baseline, selecting one documented approach. Parameterize addresses, site registry, cert paths, ports and modes. Preserve existing Nginx configuration and create backups before managed include changes. Require nginx -t before the initial graceful reload and keep new sites monitor-only. Never change production through the pack-generation environment.

## Expected deliverables

deploy/ansible/ or deploy/install/; docs/installation.md; installer tests. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Run install twice on a disposable lab and show the second run makes no unintended changes. Test invalid Nginx config rollback, missing credentials, socket ownership and successful empty-snapshot bootstrap.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/050.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 050 done --evidence docs/evidence/050.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
