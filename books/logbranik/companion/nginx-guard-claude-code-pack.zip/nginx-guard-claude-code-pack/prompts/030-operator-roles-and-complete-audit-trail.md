# 030 — Operator roles and complete audit trail

Phase: Operations controls · Recommended Claude effort: **high**
Prerequisite: 029 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Complete viewer/operator/administrator authorization across read and write APIs using separately provisioned mTLS identities. Add consistent audit events for manual bans, revokes, allowlist/mode changes, enrollment, credential changes and emergency synchronization. Record before/after versions and reasons. Keep read-only endpoints bounded and redact sensitive evidence.

## Expected deliverables

services/control/app/operators/; services/control/app/audit/; RBAC matrix tests. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Run a role/endpoint matrix including scope violations, anonymous calls and duplicate idempotency keys. Verify audit writes commit with their mutations and explain that database-admin tampering is outside append-only table guarantees.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/030.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 030 done --evidence docs/evidence/030.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
