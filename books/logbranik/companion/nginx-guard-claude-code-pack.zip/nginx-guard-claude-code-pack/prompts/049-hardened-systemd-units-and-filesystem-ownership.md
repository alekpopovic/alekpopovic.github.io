# 049 — Hardened systemd units and filesystem ownership

Phase: Deployment · Recommended Claude effort: **high**
Prerequisite: 048 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Create agent and optional central worker systemd units using least privilege, explicit state/runtime directories, restart policies and bounded resources. Configure Unix socket group sharing with Nginx and log-read access for Vector. Keep writable paths narrow; do not add CAP_NET_ADMIN, Docker socket access or Nginx reload permissions. Provide environment/credential file handling.

## Expected deliverables

deploy/systemd/; deploy/tmpfiles/; docs/permissions.md. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Validate unit syntax, run the agent under intended permissions and confirm Nginx can check while unrelated local users cannot mutate state. Test service restart and read-only filesystem restrictions without breaking state persistence.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/049.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 049 done --evidence docs/evidence/049.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
