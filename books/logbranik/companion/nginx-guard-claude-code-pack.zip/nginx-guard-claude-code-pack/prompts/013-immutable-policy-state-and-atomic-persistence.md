# 013 — Immutable policy state and atomic persistence

Phase: Local enforcement · Recommended Claude effort: **xhigh**
Prerequisite: 012 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Implement an immutable snapshot state indexed by scope and normalized exact IP, plus a bounded prefix matcher for manually provisioned allowlists. Persist epoch/revision/hash/signed bytes atomically with file fsync, rename and directory fsync before publication. Serialize updates and publish a complete memory view for concurrent readers. Enforce capacity and independent decision TTL limits. Use test-only injected trusted fixtures until signing is wired.

## Expected deliverables

services/agent/internal/state/; services/agent/internal/persistence/; state fault tests. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Race concurrent updates/checks; fault-inject write, fsync and rename failures; verify previous state stays usable and no success is acknowledged prematurely. Test restart from valid/truncated/tampered state and snapshot capacity boundaries.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/013.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 013 done --evidence docs/evidence/013.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
