# 031 — Operator CLI for investigation

Phase: Operations controls · Recommended Claude effort: **medium**
Prerequisite: 030 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Add guardctl in Go with nodes, sites, events, detections, decisions, deliveries and audit read commands. Load CA/certificate/key paths from protected config, support bounded pagination and stable JSON output, and render clear desired versus applied state. Do not print private key material or raw tokens. Add time/site/IP filters without introducing unbounded database queries.

## Expected deliverables

services/agent/cmd/guardctl/; services/agent/internal/client/; CLI tests. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Test CLI output/exit codes against a fixture API, wrong TLS identity, pagination and unavailable central service. Verify JSON output is machine-readable and terminal output safely escapes control characters from evidence.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/031.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 031 done --evidence docs/evidence/031.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
