# 005 — Build commands and test foundation

Phase: Foundation · Recommended Claude effort: **medium**
Prerequisite: 004 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Add Python lint/type/test commands, Go formatting/vet/unit/race commands, PostgreSQL integration fixtures and contract-fixture runners. Inject clocks and ID generators so later TTL/replay tests are deterministic. Provide Makefile help, narrow task targets and an initial CI skeleton that runs only implemented checks. Establish test doubles for yet-unimplemented counterparts with visible labels.

## Expected deliverables

Makefile; tests/conftest.py; services/agent/internal/testutil/; .github/workflows/ci.yml. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Run a clean build, language checks and existing tests. Verify a deliberately failing fixture is detected by the harness, then remove that temporary failure. Document which full-system gates are scheduled later.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/005.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 005 done --evidence docs/evidence/005.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
