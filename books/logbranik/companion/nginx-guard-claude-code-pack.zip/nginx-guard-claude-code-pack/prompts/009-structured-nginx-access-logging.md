# 009 — Structured Nginx access logging

Phase: Log ingestion · Recommended Claude effort: **high**
Prerequisite: 008 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Adapt the reference logging configuration to the lab and existing Nginx layout. Emit server-generated request IDs, stable site IDs, resolved client IP, pre-rewrite query-free path, status, timing, bytes and Guard outcome. Keep JSON escaping enabled and auth subrequest logging disabled. Preserve existing access logs if required. Configure immediate or measured short-flush logging and document sensitive-data exclusions.

## Expected deliverables

deploy/nginx/logging.conf; tests/e2e/test_logging.py; docs/nginx-installation.md. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Run nginx -t and issue real upstream/static requests with quotes, encoded paths and internal redirects. Parse every log line as JSON and assert no query secrets, authorization, cookies or bodies are recorded. Verify one main-request event and stable original path.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/009.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 009 done --evidence docs/evidence/009.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
