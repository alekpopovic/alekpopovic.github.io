# 037 — Snapshot coalescing and bounded delivery scaling

Phase: Fleet and observability · Recommended Claude effort: **high**
Prerequisite: 036 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Measure and improve full-snapshot fanout using dirty-agent coalescing, per-agent serialization, bounded global concurrency and latest-state supersession. Enforce 8 MiB/decision-count caps before signing and report capacity failures visibly. Prevent one offline node from blocking others. Preserve ordered desired-state semantics and do not add deltas without a new explicit protocol decision.

## Expected deliverables

outbox scheduling refinements; tests/load/snapshot_fanout/; capacity report. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Generate rapid mixed ban/revoke updates across several agents, including one offline and one slow receiver. Show convergence to latest desired state, stable memory use and no acknowledgement of an oversized or partially applied snapshot.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/037.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 037 done --evidence docs/evidence/037.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
