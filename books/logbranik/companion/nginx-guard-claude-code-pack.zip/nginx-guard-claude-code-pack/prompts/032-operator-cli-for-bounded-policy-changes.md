# 032 — Operator CLI for bounded policy changes

Phase: Operations controls · Recommended Claude effort: **high**
Prerequisite: 031 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Add explicit ban, revoke, allowlist and site-mode commands with mandatory scope, reason and TTL where relevant. Provide a dry-run that shows the concrete target and affected nodes. Use idempotency keys and optimistic versions. Make fleet/global scope an explicit flag, never the default. Show queued/applied/failed states and support a bounded wait for agent acknowledgement.

## Expected deliverables

guardctl policy commands; tests/cli/test_policy_commands/; docs/operator-cli.md. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Test accidental missing scope, expired TTL, global flag, conflict, repeated invocation and timeout waiting for one offline node. A central mutation response must not be displayed as applied everywhere.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/032.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 032 done --evidence docs/evidence/032.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
