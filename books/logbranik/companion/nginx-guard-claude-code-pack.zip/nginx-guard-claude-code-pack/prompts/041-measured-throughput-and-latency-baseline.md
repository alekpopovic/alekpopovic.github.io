# 041 — Measured throughput and latency baseline

Phase: Fleet and observability · Recommended Claude effort: **high**
Prerequisite: 040 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Run a repeatable load experiment with documented hardware, versions and configuration. Measure local auth latency at 1,000 requests/s and the whole pipeline at 100 completed log events/s, including storage footprint and CPU/RAM. Compare to provisional acceptance targets, identify bottlenecks and tune bounded batching/timeouts if justified. Preserve fail semantics during tuning.

## Expected deliverables

tests/load/; tools/benchmark/; docs/benchmarks/baseline.md. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Save actual p50/p95/p99, errors, backlog, threshold-to-applied duration and methodology. If targets fail, record the result and supported capacity instead of fabricating success. Rerun only the affected experiment after a substantive change.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/041.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 041 done --evidence docs/evidence/041.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
