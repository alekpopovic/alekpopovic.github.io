# 048 — Production images and agent release binaries

Phase: Deployment · Recommended Claude effort: **high**
Prerequisite: 047 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Build minimal pinned central images with non-root users and a separately invokable API/detector/delivery process. Produce Linux amd64/arm64 Go agent/CLI binaries with version metadata and checksums. Include a license/dependency inventory and SBOM where tooling permits. Exclude local test keys, raw logs and development data.

## Expected deliverables

services/control/Dockerfile; tools/release/; release manifest; SBOM. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Run image startup/health checks, scan dependency/image findings with triage, and verify binaries on supported architectures via execution or clearly documented cross-build limitations. Confirm artifacts contain no generated private keys.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/048.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 048 done --evidence docs/evidence/048.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
