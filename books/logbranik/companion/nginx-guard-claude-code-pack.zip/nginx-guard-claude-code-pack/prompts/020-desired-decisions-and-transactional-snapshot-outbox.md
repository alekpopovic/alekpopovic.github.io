# 020 — Desired decisions and transactional snapshot outbox

Phase: Secure synchronization · Recommended Claude effort: **xhigh**
Prerequisite: 019 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Implement central desired-state mutations for bans, revocations, allowlists and site modes with actor/reason and audit. In one transaction mark affected agents dirty and create durable outbox intent. Materialize bounded full snapshots from current state, allocating monotonic per-agent revisions and storing exact signed bytes atomically. Coalesce rapid mutations without losing revocations. Always recompute active TTLs; never refresh expiry just for delivery.

## Expected deliverables

services/control/app/policy/; services/control/app/outbox/; transaction integration tests. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Rollback mutations and assert neither desired state nor outbox survives alone. Race changes for one agent and verify ordered revisions. Test empty snapshots, a revoke overtaking a queued ban and repeated materialization with no accidental TTL extension.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/020.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 020 done --evidence docs/evidence/020.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
