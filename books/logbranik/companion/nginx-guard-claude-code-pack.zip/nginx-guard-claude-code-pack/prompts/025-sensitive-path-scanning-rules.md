# 025 — Sensitive-path scanning rules

Phase: Detection · Recommended Claude effort: **high**
Prerequisite: 024 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Add versioned sensitive-path families with bounded safe matching and the initial monitor-mode threshold from DETECTION.md. Include original path normalization that does not double-decode arbitrary strings or inspect absent query/body data. Require diversity across configured families and retain a small evidence sample. Record counts, observed window and rule version with each detection.

## Expected deliverables

services/control/app/detection/rules/path_scan.py; tests/fixtures/path_scan/. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Replay labeled scanning and benign missing-file traffic, repeated requests to one path, encoded variants, long inputs and case differences. Verify match complexity remains bounded and one missing favicon cannot trigger the rule.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/025.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 025 done --evidence docs/evidence/025.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
