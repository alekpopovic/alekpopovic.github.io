# 012 — Go agent process and local listener

Phase: Local enforcement · Recommended Claude effort: **high**
Prerequisite: 011 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Create the Go agent with strict configuration, graceful shutdown, structured logs, a local Unix HTTP listener and a separate private control listener skeleton. Set socket ownership/mode for Nginx only. Add readiness versus liveness and test-clock injection. Start unsynchronized agents as not-ready; do not silently allow from an empty accidental state. Define local-only diagnostic commands without shell execution features.

## Expected deliverables

services/agent/cmd/guard-agent/; services/agent/internal/config/; services/agent/internal/server/. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Run unit/race checks, test startup with missing directories, invalid config and occupied sockets, and verify Unix permissions. Assert visitor-accessible TCP cannot reach the check endpoint or a mutation endpoint.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/012.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 012 done --evidence docs/evidence/012.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
