# 039 — Metrics and structured cross-service diagnostics

Phase: Fleet and observability · Recommended Claude effort: **high**
Prerequisite: 038 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Expose authenticated/private metrics for ingest lag, invalid/duplicate/drop counts, queue age, detector latency, decisions, delivery failures, applied revision staleness, local auth latency, bypass/unavailable state, state capacity and certificate expiry. Use bounded labels without IP/path/request-ID cardinality. Correlate structured logs with IDs while keeping sensitive material out. Add basic scrape configuration.

## Expected deliverables

services/control/app/metrics.py; services/agent/internal/metrics/; deploy/monitoring/. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Trigger representative failures and assert metrics change with bounded label sets. Verify per-request logs are sampled or bounded as configured and a full incident can be followed without exposing secrets.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/039.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 039 done --evidence docs/evidence/039.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
