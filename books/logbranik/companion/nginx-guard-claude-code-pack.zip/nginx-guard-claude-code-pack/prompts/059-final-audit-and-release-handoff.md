# 059 — Final audit and release handoff

Phase: Release · Recommended Claude effort: **xhigh**
Prerequisite: 058 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Review the implemented repository against every requirement and acceptance invariant. Run remaining required release checks, inspect secrets/dependency findings, verify all documentation and compile a release manifest with versions, checksums, supported topology, measured capacity and known limits. Separate completed implementation, tested lab behavior and actual production deployment. Resolve blockers or explicitly leave release status blocked.

## Expected deliverables

docs/release/FINAL_REPORT.md; release manifest; final acceptance matrix; operator handoff. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Produce a requirement-to-evidence matrix, a fresh-install demonstration and a concise operator handoff. Confirm all 60 tracker rows are truthful, no mandatory test is silently skipped and production-ready language matches the evidence.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/059.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 059 done --evidence docs/evidence/059.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
