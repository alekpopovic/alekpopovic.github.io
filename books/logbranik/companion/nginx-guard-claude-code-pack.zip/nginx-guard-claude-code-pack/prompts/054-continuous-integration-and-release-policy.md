# 054 — Continuous integration and release policy

Phase: Release · Recommended Claude effort: **high**
Prerequisite: 053 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Finish CI with locked dependency installation, Python/Go checks, PostgreSQL integration, contracts, real Nginx/Vector validation and core end-to-end tests. Add protected release workflow, checksums and artifact retention. Keep performance/chaos jobs scheduled or opt-in when expensive but required before releases. Restrict workflow permissions and prevent untrusted PRs from receiving deployment secrets.

## Expected deliverables

.github/workflows/; release policy; CI execution evidence. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Run CI on a branch and demonstrate failures block release. Verify pull-request and trusted-release permissions differ, artifact checksums validate and the workflow does not automatically deploy to production from arbitrary code.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/054.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 054 done --evidence docs/evidence/054.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
