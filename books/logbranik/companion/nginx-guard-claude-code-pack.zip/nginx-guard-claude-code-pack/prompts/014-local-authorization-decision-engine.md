# 014 — Local authorization decision engine

Phase: Local enforcement · Recommended Claude effort: **high**
Prerequisite: 013 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Implement GET /v1/check on the Unix listener using validated X-Guard-IP and X-Guard-Site. Apply precedence: local bypass/emergency allowlist, central allowlist, site mode, active exact-IP bans, default allow. Return the specified outcome/revision headers and 204/403/400/503 statuses. Exclude expired entries at read time without waiting for a cleanup timer. Keep the hot path free of disk, central network and database work.

## Expected deliverables

services/agent/internal/check/; check unit tests; check benchmarks. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Test site isolation, manual global bans, allowlist precedence, monitor outcomes, unknown site, invalid IP, expiry boundaries and mapped IPv6. Use a microbenchmark only as local evidence with hardware context; run Go race tests.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/014.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 014 done --evidence docs/evidence/014.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
