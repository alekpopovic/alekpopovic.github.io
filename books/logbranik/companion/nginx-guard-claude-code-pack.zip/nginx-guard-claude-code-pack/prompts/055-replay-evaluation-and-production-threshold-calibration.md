# 055 — Replay evaluation and production threshold calibration

Phase: Release · Recommended Claude effort: **high**
Prerequisite: 054 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Build an offline replay command that uses the same detection code against labeled or redacted representative logs with actions disabled. Report candidate bans, benign collisions, counts by rule/site and late-event handling. Tune thresholds per site based on evidence; keep login/volume/error rules monitor-only without verified semantics. Store rule versions and an operator-reviewed calibration record.

## Expected deliverables

tools/replay/; docs/release/calibration.md; versioned rule defaults. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Run the supplied synthetic dataset and any authorized representative dataset available. Show false-positive cases and their effect on tuning; do not manufacture a production accuracy figure or silently label unknown traffic as malicious.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/055.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 055 done --evidence docs/evidence/055.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
