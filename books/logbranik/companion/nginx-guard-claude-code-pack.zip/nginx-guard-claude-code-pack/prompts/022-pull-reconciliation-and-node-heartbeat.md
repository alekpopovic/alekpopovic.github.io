# 022 — Pull reconciliation and node heartbeat

Phase: Secure synchronization · Recommended Claude effort: **high**
Prerequisite: 021 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Implement authenticated self-only snapshot polling and heartbeats. Agents reconcile every 15 seconds with jitter, using the same signature/revision pipeline as push. Return 204 for current state; regenerate expired undispatched envelopes with new revisions. Report applied revision, version, bypass, health and capacity without secrets. Detect stale agents and certificate renewal needs.

## Expected deliverables

services/control/app/api/agents.py; services/agent/internal/sync/; synchronization tests. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Drop push traffic and show pull catches up; race push/pull arrivals and prove convergence. An agent must not read another agent snapshot. Verify reconnect after a long outage does not revive expired or revoked decisions.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/022.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 022 done --evidence docs/evidence/022.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
