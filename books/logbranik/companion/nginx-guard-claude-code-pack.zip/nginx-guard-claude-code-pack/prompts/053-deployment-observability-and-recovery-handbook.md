# 053 — Deployment observability and recovery handbook

Phase: Deployment · Recommended Claude effort: **medium**
Prerequisite: 052 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Consolidate installation, topology/trusted-proxy settings, capacity, metrics, false-positive recovery, emergency bypass, cert rotation, storage pressure, central outage, agent outage and disaster recovery into an operator handbook. Include exact commands validated in the lab and how to inspect desired versus applied state. Keep secrets and private topology examples out of public documentation.

## Expected deliverables

docs/operator-handbook.md; docs/runbooks/index.md; documentation checks. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Follow the handbook from a clean lab as an operator and fix missing steps. Verify every referenced command/file exists and critical failure scenarios link to the corresponding evidence and alert.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/053.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 053 done --evidence docs/evidence/053.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
