# 001 — Version selection and reproducible dependencies

Phase: Foundation · Recommended Claude effort: **high**
Prerequisite: 000 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Check official compatibility documentation for currently supported Python, Go, PostgreSQL, Nginx OSS and Vector releases. Pin exact development versions and container digests where practical; lock Python dependencies including FastAPI, Pydantic, SQLAlchemy, Alembic, psycopg and cryptography. Initialize the Go module using the standard library where sufficient. Document upgrade policy and record whether auth_request and realip modules are present. Never use floating latest production tags.

## Expected deliverables

services/control/pyproject.toml; dependency lock; services/agent/go.mod; docs/versions.md. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Install from the lockfiles in a clean environment, compile a minimal Go binary and run dependency checks. Save the actual version outputs and official reference links. An inaccessible registry is a blocker, not permission to invent a version.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/001.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 001 done --evidence docs/evidence/001.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
