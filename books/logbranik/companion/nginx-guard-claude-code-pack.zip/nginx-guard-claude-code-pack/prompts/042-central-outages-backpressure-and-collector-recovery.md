# 042 — Central outages, backpressure and collector recovery

Phase: Failure validation · Recommended Claude effort: **high**
Prerequisite: 041 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Exercise a sustained central outage with active local bans, new traffic, Vector buffering, rotating log files and bounded storage. Bring central back and drain replay while preventing stale evidence from generating fresh bans. Test ingest overload and permanent request errors. Document maximum supported outage from measured disk and retention settings.

## Expected deliverables

tests/chaos/test_central_outage.py; collector recovery report. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Track unique request IDs through restart/recovery, report any unavoidable loss bounds, verify original ban expiry, and ensure local auth does not call central while offline. Confirm buffer/disk/lag alerts fire before exhaustion.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/042.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 042 done --evidence docs/evidence/042.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
