# 051 — Database backup and tested restore

Phase: Deployment · Recommended Claude effort: **xhigh**
Prerequisite: 050 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Implement documented encrypted/permission-controlled PostgreSQL backup and restoration commands using the deployment platform facilities. Restore into an isolated instance and verify event/policy/audit consistency. Address per-agent revision high-water marks after a stale restore before reconnecting the fleet. Provide operator-assisted recovery or explicit epoch re-enrollment; never auto-trust a changed epoch.

## Expected deliverables

docs/runbooks/backup-restore.md; tools/backup/; restore integration evidence. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Restore a backup older than a later applied/revoked decision and prove the agent rejects rollback. Demonstrate the chosen reconciliation recovery and record restore duration, data-loss window and verification results.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/051.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 051 done --evidence docs/evidence/051.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
