# 007 — Bounded NDJSON ingestion

Phase: Log ingestion · Recommended Claude effort: **high**
Prerequisite: 006 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Implement POST /v1/events:batch with bounded streaming decode, line and event limits, exact NDJSON framing and bounded gzip decompression. Authenticate before expensive processing. Validate each record against the certificate-derived node/site registry. Return accepted/duplicate/quarantined counts only after transaction commit. Quarantine invalid individual records with capped redacted evidence; distinguish whole-body errors from transient database failures.

## Expected deliverables

services/control/app/api/events.py; services/control/app/ingest/; tests/integration/test_ingest.py. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Send valid/mixed/empty/array/malformed/oversized batches and a compression bomb fixture. Prove limits apply to decoded bytes and a site not assigned to the collector is rejected. Simulate a database error and verify no 2xx response.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/007.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 007 done --evidence docs/evidence/007.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
