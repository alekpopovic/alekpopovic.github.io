# 045 — Hostile inputs and cross-scope security tests

Phase: Failure validation · Recommended Claude effort: **xhigh**
Prerequisite: 044 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Build a security regression suite for forged forwarding/Guard headers, cross-site logs, Host alias confusion, NDJSON parser boundaries, gzip limits, signature mutation, replay and callback destination abuse. Fuzz bounded Go/Python parsers where practical. Review control and query endpoints for excessive resource use and authorization gaps. Keep testing confined to the lab.

## Expected deliverables

tests/security/; Go fuzz targets; docs/security-review.md. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Run the role/identity/replay matrix and bounded fuzz campaigns with recorded seeds. Demonstrate that a collector can submit only its own authorized site logs and cannot mutate policy, read another node state or select an arbitrary dispatch target.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/045.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 045 done --evidence docs/evidence/045.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
