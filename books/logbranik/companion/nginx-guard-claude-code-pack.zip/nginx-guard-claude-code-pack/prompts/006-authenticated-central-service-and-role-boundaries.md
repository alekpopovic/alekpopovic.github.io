# 006 — Authenticated central service and role boundaries

Phase: Log ingestion · Recommended Claude effort: **xhigh**
Prerequisite: 005 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Implement FastAPI configuration, startup/shutdown, database sessions and health endpoints behind a private mTLS TLS ingress. Derive peer identity only from ingress-overwritten verified fields, and prevent direct public access to the application port. Resolve certificates to collector, agent, dispatcher or operator roles with node/site scope. Add structured request IDs and redacted logs. Enrollment stays an offline administrator action.

## Expected deliverables

services/control/app/main.py; services/control/app/security/; deploy/central-tls/. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Test missing/forged identity headers, direct-app exposure controls, wrong certificate roles, revoked identities and unknown nodes. A collector must not call operator or agent synchronization endpoints. Verify probes do not expose secrets.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/006.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 006 done --evidence docs/evidence/006.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
