# 000 — Repository inventory and project bootstrap

Phase: Foundation · Recommended Claude effort: **high**
Prerequisite: No prior prompt; inspect the repository first

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Inspect the current repository, CLAUDE.md and any AGENTS.md instructions, Git changes, installed tooling and deployment assumptions. Create services/control, services/agent, deploy, tests/contracts, tests/e2e and docs/evidence only where appropriate. Record the actual Nginx version/modules, operating system and direct/proxy topology if available; mark unknown facts explicitly. Merge the project instruction template, add a README and a minimal Makefile with documented future targets. Record the architecture decisions without changing the agreed stack.

## Expected deliverables

README.md; Makefile; docs/decisions/001-scope.md; merged CLAUDE.md. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Show repository inventory, preserved existing files and the proposed directory map. Run available baseline checks and record unavailable tools without claiming success. Verify the pack remains under docs/claude-pack and all paths resolve.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/000.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 000 done --evidence docs/evidence/000.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
