# 026 — Login-abuse rule with explicit endpoint semantics

Phase: Detection · Recommended Claude effort: **high**
Prerequisite: 025 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Implement login-abuse detection only for configured site-specific login routes and declared failure status semantics. Keep it monitor-only until an operator records verified semantics. Exclude Guard-generated 403s and application errors that do not mean authentication failure. Document how an application-specific signal could later support failure responses returned as HTTP 200 without pretending access logs expose that detail.

## Expected deliverables

services/control/app/detection/rules/login_abuse.py; endpoint configuration; login fixtures. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Replay successful/failed logins, unrelated 403s, a site returning 200 on bad credentials and shared NAT traffic. Verify unconfigured routes do not contribute and blocked traffic cannot inflate failure counters.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/026.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 026 done --evidence docs/evidence/026.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
