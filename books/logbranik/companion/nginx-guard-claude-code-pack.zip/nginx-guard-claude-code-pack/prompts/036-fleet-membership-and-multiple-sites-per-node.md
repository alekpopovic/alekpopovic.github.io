# 036 — Fleet membership and multiple sites per node

Phase: Fleet and observability · Recommended Claude effort: **high**
Prerequisite: 035 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Extend lab to at least two edge nodes and two sites with explicit node/site/agent enrollment and certificate role mapping. Create only the appropriate per-agent snapshot view and destination. Handle site addition/removal and node decommission with explicit cleanup/revocation semantics. Verify collector identity is node-scoped and agent identity is self-scoped.

## Expected deliverables

fleet registry APIs/CLI; deploy/compose/fleet profile; fleet e2e tests. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Block an IP for a shared site on both nodes, then for a site on one node only. Test unauthorized site logs, unknown host routing, removed sites and decommissioned certificates. Verify delivery to an unrelated node is impossible.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/036.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 036 done --evidence docs/evidence/036.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
