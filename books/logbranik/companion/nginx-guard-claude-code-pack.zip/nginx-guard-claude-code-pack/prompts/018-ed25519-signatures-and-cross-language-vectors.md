# 018 — Ed25519 signatures and cross-language vectors

Phase: Secure synchronization · Recommended Claude effort: **xhigh**
Prerequisite: 017 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Implement the exact domain-separated byte-signing contract with Python cryptography and Go crypto/ed25519. Add bounded envelope decoding, duplicate-key rejection, pinned public-key lookup and independent semantic validation after signature verification. Generate reproducible test vectors with test-only keys. Keep production private keys outside code and outside the edge host. Do not invent custom cryptographic primitives.

## Expected deliverables

services/control/app/signing/; services/agent/internal/signature/; tests/contracts/signatures/. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Verify Python-signed bytes in Go and reject one-byte mutations, wrong keys, altered metadata, oversized envelopes, unsupported versions and duplicate payload keys. Test whitespace changes to prove verification uses signed raw bytes, not JSON reserialization.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/018.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 018 done --evidence docs/evidence/018.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
