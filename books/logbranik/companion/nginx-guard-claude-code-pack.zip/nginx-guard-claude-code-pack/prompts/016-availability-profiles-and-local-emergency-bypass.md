# 016 — Availability profiles and local emergency bypass

Phase: Local enforcement · Recommended Claude effort: **xhigh**
Prerequisite: 015 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Implement and document fail-closed as the baseline. Add an explicit optional fail-open Nginx include that maps only auth-backend 500/502/503/504 inside the internal subrequest location to a local 204 fallback. Preserve 403 blocks and existing application authentication. Add a root/operator-controlled local emergency bypass file or CLI operation, separate from central policy, with visible metrics and expiry where appropriate.

## Expected deliverables

deploy/nginx/availability/; services/agent/internal/emergency/; availability e2e tests. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Kill, hang and overload the agent; test both profiles with GET, POST bodies and application 500 responses. A real 403 must never be converted to allow. Verify bypass activation/deactivation, logging and restoration, and document residual bypass coverage.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/016.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 016 done --evidence docs/evidence/016.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
