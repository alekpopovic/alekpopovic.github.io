# 027 — Request-volume and error anomaly monitoring

Phase: Detection · Recommended Claude effort: **high**
Prerequisite: 026 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Implement monitor-only request-volume and 404-diversity detections with independent thresholds, bounded windows and site-specific baselines. Keep high volume alone from becoming an automatic ban. Add allowlist handling and a minimum observation period for recommendations. Avoid high-cardinality metric labels and never trust a claimed crawler user-agent as an exemption.

## Expected deliverables

services/control/app/detection/rules/anomalies.py; benign/abuse replay fixtures. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Replay a normal burst, shared NAT, a crawler-like pattern, deployment-related broken assets and actual path scanning. Verify only explainable monitor detections occur for ambiguous traffic and resource use stays bounded.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/027.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 027 done --evidence docs/evidence/027.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
