# 008 — Deduplication and durable processing queue

Phase: Log ingestion · Recommended Claude effort: **xhigh**
Prerequisite: 007 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Atomically insert dedup identity, accepted raw events and processing work using node_id plus request_id. Compare immutable hashes on duplicate IDs and quarantine conflicting payloads without changing the original. Implement a retry-safe Postgres worker claim strategy with bounded batches and recovery. Preserve dedup records independently of raw-event retention. Never increment detector counters from the HTTP handler before durable acceptance.

## Expected deliverables

services/control/app/ingest/persistence.py; services/control/app/workers/queue.py; queue integration tests. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Retry the same batch concurrently and after a simulated lost response; it must create one logical event and one effect. Kill a worker before/after commit and show uncommitted work is recovered. Verify the conflicting-ID path produces a visible security counter.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/008.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 008 done --evidence docs/evidence/008.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
