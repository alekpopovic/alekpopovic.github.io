# 010 — Vector transport and disk buffering

Phase: Log ingestion · Recommended Claude effort: **high**
Prerequisite: 009 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Adapt the reference Vector file source/remap/HTTP sink to the pinned version. Normalize numeric fields and timestamps, use NDJSON with explicit framing, mTLS, a bounded disk buffer and a batch size below ingest limits. Preserve file checkpoints and expose dropped/invalid events. Provide rotation and buffer permissions. Keep identity derived from transport rather than trusting payload node identifiers.

## Expected deliverables

deploy/vector/vector.toml; collector fixture tests; docs/collector.md. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Run vector validate and a capture-server integration test that inspects real outgoing bytes, content type and certificate identity. Exercise 200, 400, 401, 413, 429 and 503 responses and document retry versus permanent failure. Restart Vector with pending buffered events.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/010.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 010 done --evidence docs/evidence/010.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
