# 029 — Automatic detection-to-block demonstration

Phase: Detection · Recommended Claude effort: **high**
Prerequisite: 028 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Build an end-to-end lab scenario using enough controlled requests to trigger the tuned sensitive-path rule. Correlate request IDs, detector window, decision, outbox, signed revision, agent acknowledgement and denied follow-up request. Include a benign replay scenario and a delayed backlog scenario. Make the demo reset only isolated test state, never arbitrary deployments.

## Expected deliverables

tools/demo-detection.sh; tests/e2e/test_auto_block.py; docs/evidence/029.md. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Measure each pipeline stage and threshold-to-applied duration at a documented input rate. Verify subsequent requests are blocked without reload, expire/revoke correctly, and never claim the already-completed triggering request was prevented.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/029.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 029 done --evidence docs/evidence/029.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
