# 015 — Nginx auth_request integration

Phase: Local enforcement · Recommended Claude effort: **xhigh**
Prerequisite: 014 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Wire the protected content location to the agent Unix socket using an internal auth location, disabled recursive auth, no request body and overwritten identity headers. Implement stable site binding and a default host policy. Do not use rewrite-phase return 200 as protected test content. Audit static, regex, named and internal redirects, plus existing auth_request or satisfy directives. Keep auth caching off.

## Expected deliverables

deploy/nginx/guard-auth.conf; deploy/nginx/site-example.conf; tests/e2e/test_auth_request.py. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Run nginx -t and real allow/deny tests against an echo upstream and static file. Verify upstream never receives a denied request, method/body remain intact, internal auth URI is inaccessible externally and visitor X-Guard headers cannot change the decision.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/015.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 015 done --evidence docs/evidence/015.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
