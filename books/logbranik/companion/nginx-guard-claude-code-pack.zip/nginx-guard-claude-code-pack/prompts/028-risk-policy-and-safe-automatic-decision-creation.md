# 028 — Risk policy and safe automatic decision creation

Phase: Detection · Recommended Claude effort: **xhigh**
Prerequisite: 027 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Connect eligible detections to the transactional desired-state service. Enforce monitor/enforce mode, exact site/IP scope, allowlists, TTL bounds, one active effect per rule/window and no automatic renewal in the MVP. Add revocation suppression, per-site/per-minute ban caps and a visible automatic-enforcement circuit breaker. Exclude stale events and Guard-denied traffic before the policy stage.

## Expected deliverables

services/control/app/detection/policy.py; policy safety tests. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Prove retries do not duplicate bans, a revoke is not instantly undone by old evidence, outages/backfills do not create fresh bans and circuit-breaker activation is audited. Test allowlist changes racing with decision creation.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/028.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 028 done --evidence docs/evidence/028.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
