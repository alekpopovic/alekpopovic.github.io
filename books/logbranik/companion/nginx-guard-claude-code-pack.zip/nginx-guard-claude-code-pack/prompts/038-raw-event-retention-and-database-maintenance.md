# 038 — Raw-event retention and database maintenance

Phase: Fleet and observability · Recommended Claude effort: **high**
Prerequisite: 037 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Implement configurable raw, quarantine, aggregate, dedup and audit retention from OPERATIONS.md with bounded maintenance jobs. Introduce partitioning only if measured volume justifies it, preserving node/request uniqueness separately. Preserve compact decision explanations and pending work. Add disk/WAL growth monitoring and an administrative retention dry-run.

## Expected deliverables

services/control/app/workers/retention.py; retention tests; docs/storage-sizing.md. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Advance a test clock and prune eligible data without removing active decisions, pending jobs or required dedup keys. Retry events near/beyond retention limits and show old data cannot create fresh bans. Measure database storage per event.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/038.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 038 done --evidence docs/evidence/038.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
