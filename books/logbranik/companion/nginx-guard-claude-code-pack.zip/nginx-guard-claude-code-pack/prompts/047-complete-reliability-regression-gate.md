# 047 — Complete reliability regression gate

Phase: Failure validation · Recommended Claude effort: **high**
Prerequisite: 046 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Combine the implemented tests into a reproducible full-stack gate covering manual/automatic ban, revoke, TTL, restart, push/pull races, stale backlog, multi-site isolation and no-reload proof. Replace temporary counterpart mocks with real components on core paths. Produce a traceable pass/fail matrix against ACCEPTANCE.md and fix release-blocking findings.

## Expected deliverables

tests/e2e/full_gate/; docs/release/acceptance-matrix.md. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Run the full gate from a clean local environment and store actual outputs. Clearly list skipped checks with reasons and keep the milestone blocked if a required production invariant is unverified.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/047.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 047 done --evidence docs/evidence/047.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
