# 033 — Allowlist precedence and revocation race handling

Phase: Operations controls · Recommended Claude effort: **xhigh**
Prerequisite: 032 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Implement site/global manual central allowlists, exact IP and bounded CIDR entries, expiry and local emergency precedence. Recompute snapshots when allowlists change and preserve local controls outside remote snapshots. Ensure revocation suppression and detector decisions observe the newest policy under concurrency. Explain a decision that exists but is overridden by an allowlist.

## Expected deliverables

policy precedence logic; concurrency fixtures; docs/policy-precedence.md. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Race detector updates with allowlist insert/delete and revoke operations. Test IPv6 prefixes, overlapping scopes and expired allowlists. Verify a delayed signed snapshot cannot undo a newer revoke or local emergency bypass.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/033.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 033 done --evidence docs/evidence/033.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
