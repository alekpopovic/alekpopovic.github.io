# 003 — Local networks and development certificates

Phase: Foundation · Recommended Claude effort: **high**
Prerequisite: 002 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Build a Docker Compose lab with separate edge and central networks, PostgreSQL and an echo application. Add development-only CA/certificate generation for collector, dispatcher, agent and operator roles using fresh keys. Publish services only on loopback where access is needed. Model the Nginx-to-agent Unix socket using explicit volume ownership. Keep generated private material ignored and distinguish lab trust from production enrollment.

## Expected deliverables

deploy/compose/; tools/dev-pki/; .gitignore; docs/local-development.md. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Validate Compose, inspect network exposure and prove a wrong-CA client is rejected by a TLS fixture. Ensure no default certificate or password is committed. Verify Nginx can access only the intended socket directory.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/003.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 003 done --evidence docs/evidence/003.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
