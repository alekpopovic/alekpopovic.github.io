# 034 — Evidence search and decision explanations

Phase: Operations controls · Recommended Claude effort: **medium**
Prerequisite: 033 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Add bounded query APIs/CLI for a decision timeline including rule version, window counts, evidence IDs, scope, original expiry, suppression, allowlist override and delivery acknowledgements. Use indexed filters and cursor pagination. Retain compact explanation summaries after raw-event retention expires. Escape hostile paths in all terminal/HTML output if any UI is added.

## Expected deliverables

services/control/app/api/investigation.py; guardctl explain; timeline integration tests. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Investigate a known lab detection from CLI and verify every timeline reference resolves or reports retention expiry honestly. Exercise pagination stability and hostile control characters without terminal injection.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/034.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 034 done --evidence docs/evidence/034.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
