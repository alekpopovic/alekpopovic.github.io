# 021 — Reliable push delivery and applied acknowledgements

Phase: Secure synchronization · Recommended Claude effort: **high**
Prerequisite: 020 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Implement a delivery worker with leased Postgres jobs, bounded parallelism, exponential backoff/jitter and registered destination validation. Send stored signed bytes with mTLS, do not follow arbitrary redirects, and validate agent/epoch/revision/hash acknowledgement. Classify permanent versus transient failures. Supersede expired pending envelopes by fresh higher-revision snapshots; never replay stale state after revocation. Expose desired/queued/applied separately.

## Expected deliverables

services/control/app/workers/delivery.py; delivery integration tests. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Test timeout after successful application, duplicate response delivery, wrong ack hash, wrong agent, network outage, redirection to an unapproved host and expired pending payloads. Prove retries converge without duplicate policy effects.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/021.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 021 done --evidence docs/evidence/021.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
