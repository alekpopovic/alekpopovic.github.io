# 024 — Event-time aggregation and concurrency correctness

Phase: Detection · Recommended Claude effort: **xhigh**
Prerequisite: 023 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Implement bounded fixed-window aggregation by site/IP/rule with freshness and future-skew limits. Use durable queue claiming plus correct transactional counter updates or serialization of shared keys across workers. Bound distinct-path storage and evidence references. Inject the clock, separate event time from received time, and retain late events for investigation while excluding them from automatic action.

## Expected deliverables

services/control/app/detection/windows.py; detection concurrency tests. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Process duplicate, out-of-order, future and delayed events across simultaneous workers. Verify counts match a reference model after crashes/retries, threshold boundaries are deterministic and no process-local counter loses state on restart.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/024.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 024 done --evidence docs/evidence/024.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
