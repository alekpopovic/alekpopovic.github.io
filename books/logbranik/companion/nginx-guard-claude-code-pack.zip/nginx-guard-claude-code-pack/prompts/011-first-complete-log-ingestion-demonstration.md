# 011 — First complete log ingestion demonstration

Phase: Log ingestion · Recommended Claude effort: **high**
Prerequisite: 010 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Connect real lab Nginx logs through Vector to the authenticated API and PostgreSQL. Supply a scripted demonstration with request ID correlation from HTTP request to stored row and processing state. Add collector rotation and reconnect scenarios. Measure request-finish-to-ingest delay under a modest documented load without claiming enforcement exists yet.

## Expected deliverables

tests/e2e/test_ingestion_flow.py; tools/demo-ingest.sh; docs/evidence/011.md. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Demonstrate normal traffic, temporary central outage, log rotation and collector restart. Compare sent unique request IDs with accepted/deduplicated rows, explain any limits, and save timing evidence. End-to-end tests must use actual components rather than only mocks.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/011.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 011 done --evidence docs/evidence/011.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
