# 044 — TLS and signing-key lifecycle

Phase: Failure validation · Recommended Claude effort: **xhigh**
Prerequisite: 043 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Implement operational certificate renewal, peer revocation and signing-key overlap rotation. Provision new verification keys separately, re-sign current state with newer revisions, then retire old trust after confirming nodes. Handle saved snapshots signed by retired keys with an explicit recovery procedure. Avoid dynamically trusting a key delivered inside an unverified control message.

## Expected deliverables

tools/pki/; docs/runbooks/key-rotation.md; security lifecycle tests. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Test expired certs, wrong SAN/role, revoked peer, overlapping keys, retired keys and an offline agent returning after rotation. Verify production key files have appropriate ownership and do not appear in archives, logs or evidence.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/044.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 044 done --evidence docs/evidence/044.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
