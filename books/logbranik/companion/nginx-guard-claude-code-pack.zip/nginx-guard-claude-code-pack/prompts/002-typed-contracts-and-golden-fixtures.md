# 002 — Typed contracts and golden fixtures

Phase: Foundation · Recommended Claude effort: **high**
Prerequisite: 001 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Implement Python and Go representations for event, decision, snapshot payload, envelope and acknowledgement from CONTRACTS.md. Add strict IP normalization, duplicate-key rejection where necessary, length/count limits and timestamp handling. Create shared unsigned fixtures and frozen-clock examples for IPv4, IPv6, mapped IPv6, site scopes and expiry. Define content-type and error shapes before endpoint implementation.

## Expected deliverables

services/control/app/contracts/; services/agent/internal/contracts/; tests/contracts/. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Load the same valid and invalid fixtures in both languages. Reject hostnames, zone identifiers, bad dates, oversized IDs, duplicate JSON keys and unsupported versions. Verify mapped IPv6 normalization matches Python and Go.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/002.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 002 done --evidence docs/evidence/002.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
