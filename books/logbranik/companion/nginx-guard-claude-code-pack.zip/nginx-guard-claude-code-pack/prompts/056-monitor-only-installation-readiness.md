# 056 — Monitor-only installation readiness

Phase: Release · Recommended Claude effort: **high**
Prerequisite: 055 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Prepare the first real-environment rollout package from observed topology, actual versions and intended sites. Validate private connectivity, mTLS enrollment, proxy trust, Nginx location coverage, storage budget, backups and operator recovery access. Supply a concrete monitor-only deployment diff and commands. If infrastructure access is unavailable, complete a reproducible lab rehearsal and mark real deployment pending.

## Expected deliverables

docs/release/readiness.md; environment inventory template; monitor rollout evidence. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Confirm logs arrive, identities match, snapshots synchronize and would-block outcomes are visible without denying visitors. Save readiness evidence or an exact unresolved-input list; never claim a deployment that was not performed.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/056.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 056 done --evidence docs/evidence/056.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
