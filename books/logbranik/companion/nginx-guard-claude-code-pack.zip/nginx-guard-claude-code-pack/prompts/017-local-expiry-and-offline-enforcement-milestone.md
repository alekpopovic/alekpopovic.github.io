# 017 — Local expiry and offline enforcement milestone

Phase: Local enforcement · Recommended Claude effort: **high**
Prerequisite: 016 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Demonstrate the local request path independently of central services using explicitly test-only policy injection fixtures. Add background cleanup of expired entries while keeping read-time expiry authoritative. Validate monitor/enforce/bypass precedence, ordinary agent restart and bounded memory under repeated state replacement. Keep any fixture injection API out of production builds and make its status obvious in test configuration.

## Expected deliverables

tests/e2e/test_local_enforcement.py; agent expiry maintenance; docs/evidence/017.md. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Disconnect central network access and show local allow/block/expiry behavior still works. Restart the agent with test state, run concurrent check/update traffic and verify bounded memory plus consistent site scope. Confirm production builds expose no unauthenticated fixture-loading endpoint.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/017.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 017 done --evidence docs/evidence/017.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
