# Common execution contract

Read root CLAUDE.md, the pack's CLAUDE.md, and any existing repository AGENTS.md.
Preserve unrelated changes. Application paths below are
relative to the application repository; the pack is `docs/claude-pack/`.

Before implementation, read `tracking/state.json`, `tracking/HANDOFF.md`,
`docs/ARCHITECTURE.md`, `docs/CONTRACTS.md`, `docs/NGINX_INTEGRATION.md`,
`docs/SECURITY.md` and the relevant acceptance cases in this pack. Inspect existing code;
adapt it rather than creating parallel incompatible implementations. Run one prompt at a time.

Keep the fixed stack and trust boundaries. Use only Nginx OSS-compatible directives. Request
checks stay local and in memory. Do not introduce remote per-request authorization, paid
Nginx features, unbounded queues, hidden failure bypasses, shell-based control endpoints or
unverified TLS. Defaults are monitor-only with TTL-bound exact-IP site decisions.

Implement executable code and tests appropriate to the task. Do not stop at a plan. Use test
doubles only for counterparts not built yet and label them. Run actual tests; missing tools or
infrastructure are recorded as blockers, never fabricated passes. Development work does not
authorize unrequested production changes. Use official docs for the pinned versions.

At completion save `docs/evidence/NNN.md` in the application repo with the changed behavior,
commands run, actual results, known gaps and relevant commit ID if one exists. Update the
tracker and handoff. Mark done only after the task's criteria pass. A concise final report names
the implemented outcome, checks, limitations and next prompt. Do not auto-execute the next
prompt unless the user has separately requested continuous execution.

## Claude Code session discipline

Use the individual task file rather than loading all 60 prompts. The task effort is advisory;
select it through the client's supported controls if desired, with no silent setting changes.
When a short plan helps, follow it with implementation in the same authorized session.
Update the handoff before context compaction or interruption. Read the current code on resume.
The project instruction template is CLAUDE.project-template.md. Existing AGENTS.md rules
remain relevant and must be read explicitly; do not overwrite them during migration.
