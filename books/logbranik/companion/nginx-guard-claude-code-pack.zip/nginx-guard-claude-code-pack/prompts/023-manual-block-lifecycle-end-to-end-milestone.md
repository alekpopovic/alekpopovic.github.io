# 023 — Manual block lifecycle end-to-end milestone

Phase: Secure synchronization · Recommended Claude effort: **high**
Prerequisite: 022 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Create a minimal authenticated operator API flow to ban one documentation IP on one lab site, view desired/delivery status, revoke and observe expiry. Connect all real components, including signing and mTLS. Provide a repeatable lab script with a trusted proxy fixture for synthetic source identities; never enable arbitrary X-Forwarded-For in production. Record Nginx worker identities before and after policy changes.

## Expected deliverables

tools/demo-block.sh; tests/e2e/test_manual_lifecycle.py; docs/evidence/023.md. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Show allow -> block -> revoke -> allow and a separate TTL expiry on IPv4 and IPv6. Confirm another site is unaffected and Nginx worker PIDs/start times remain stable. Capture real acknowledgement and request/log evidence with secrets redacted.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/023.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 023 done --evidence docs/evidence/023.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
