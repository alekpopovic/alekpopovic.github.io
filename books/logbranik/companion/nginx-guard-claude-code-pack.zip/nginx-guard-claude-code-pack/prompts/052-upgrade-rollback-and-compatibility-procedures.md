# 052 — Upgrade, rollback and compatibility procedures

Phase: Deployment · Recommended Claude effort: **high**
Prerequisite: 051 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Define rolling upgrade order for central, agent and Nginx/Vector configuration, including schema compatibility windows and contract-version negotiation. Build a rollback procedure preserving desired state, agent snapshots and audit history. For a breaking epoch/protocol change, require explicit migration rather than guessing compatibility. Document separate initial config reload versus routine policy updates.

## Expected deliverables

docs/runbooks/upgrade.md; docs/runbooks/rollback.md; compatibility tests. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Exercise an upgrade and rollback in the two-node lab with one older agent, in-flight delivery and active TTL bans. Verify unsupported versions fail visibly, requests follow configured availability policy and no expired/revoked ban reappears.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/052.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 052 done --evidence docs/evidence/052.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
