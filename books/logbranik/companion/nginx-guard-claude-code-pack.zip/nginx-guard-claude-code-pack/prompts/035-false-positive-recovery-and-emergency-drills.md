# 035 — False-positive recovery and emergency drills

Phase: Operations controls · Recommended Claude effort: **high**
Prerequisite: 034 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Write and execute the false-positive and agent-outage runbooks using guardctl and the local bypass mechanism. Revoke one ban, apply a narrow expiring allowlist when justified, verify acknowledgements and test restoration of normal enforcement. Add circuit-breaker inspection/reset commands with actor and reason. Do not delete all policy state as a shortcut.

## Expected deliverables

docs/runbooks/false-positive.md; docs/runbooks/agent-outage.md; drill evidence. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Demonstrate recovery while one agent is disconnected and distinguish its stale status from applied nodes. Confirm allowlist expiry and bypass removal behave predictably, and preserve an audit trail plus a short incident report.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/035.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 035 done --evidence docs/evidence/035.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
