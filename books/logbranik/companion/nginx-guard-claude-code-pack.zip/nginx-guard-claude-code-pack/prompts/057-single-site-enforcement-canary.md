# 057 — Single-site enforcement canary

Phase: Release · Recommended Claude effort: **high**
Prerequisite: 056 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

For an authorized target with monitor evidence, enable one calibrated high-confidence rule on one site with short bounded TTLs and a preconfigured rollback. Observe auth latency, errors, new-ban rate, false positives and applied revisions. Keep every other site in its prior mode. If production execution is outside current authorization/access, deliver the exact reviewed canary change and exercise it in the lab.

## Expected deliverables

docs/release/canary.md; canary commands/change manifest; observed results. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Verify an isolated controlled probe is blocked, normal paths work, revoke/expiry restore access and no Nginx reload occurs. Record canary duration and observed metrics; unmet acceptance gates prevent broader enforcement.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/057.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 057 done --evidence docs/evidence/057.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
