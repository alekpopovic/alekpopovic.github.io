# 043 — Clock, TTL and restart fault matrix

Phase: Failure validation · Recommended Claude effort: **xhigh**
Prerequisite: 042 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Implement clock-health handling, monotonic deadlines while running and restart behavior for saved states. Simulate forward/backward wall-clock movement, invalid startup time, expiry during downtime and corrupt persisted snapshots. Ensure delivery freshness and individual ban expiry remain separate concepts. Document unavailable-state behavior when trustworthy time cannot be established.

## Expected deliverables

agent/control clock handling; tests/chaos/test_time_and_restart/. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Use injected clocks plus process restart tests to show no ban is silently extended. Verify stale delivery cannot be newly applied, already-applied valid saved decisions survive ordinary restart, and invalid time is visible under both Nginx availability profiles.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/043.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 043 done --evidence docs/evidence/043.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
