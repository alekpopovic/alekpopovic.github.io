# 019 — Private mTLS snapshot receiver

Phase: Secure synchronization · Recommended Claude effort: **xhigh**
Prerequisite: 018 completed with evidence

## Task

Read `docs/claude-pack/prompts/COMMON.md` and apply its execution contract. Inspect the
current implementation and evidence before changing files. Keep ordinary Nginx OSS support.

Expose POST /v1/snapshots only on the private agent control listener with required client certificate and explicit dispatcher-role authorization. Validate signature, agent ID, pinned epoch, freshness, limits and decision scope before state application. Enforce revision replay rules and duplicate acknowledgements exactly. Persist, publish and acknowledge under serialized update handling; return a hash-bound acknowledgement.

## Expected deliverables

services/agent/internal/control/; TLS/control integration tests. These are suggested repository paths; reuse an established equivalent where present
and record the mapping. Update the relevant documentation alongside behavior changes.

## Acceptance and verification

Exercise expired/wrong-role certificates, wrong agent/epoch, lower revisions, same-revision conflicting bytes, stale new payloads and idempotent repeats. Check restart preserves replay protection and disk failure cannot return an applied acknowledgement.

## Claude execution notes

Use `docs/claude-pack/CLAUDE.md` for session rules. The effort recommendation is optional
and model-dependent. Implement and verify this task before advancing; preserve any existing
progress and update the handoff before a context break.

## Completion record

Write `docs/evidence/019.md` with actual commands/results and remaining limits.
Update `docs/claude-pack/tracking/HANDOFF.md`. Then run:

```bash
python3 docs/claude-pack/tools/track.py set 019 done --evidence docs/evidence/019.md
```

If any mandatory criterion cannot be verified, keep this prompt blocked and record the exact
dependency. Do not advance completion state on the basis of stubs or an unrun test.
