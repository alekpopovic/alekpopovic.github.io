# Claude Code edition 1.1.0

Released 2026-10-10, Europe/Belgrade.

- Added native CLAUDE.md project contract and root import template.
- Rewrote bootstrap/resume guidance for Claude Code and added next-task, phase and checkpoint prompts.
- Updated all 60 prompt paths to docs/claude-pack and reasoning metadata to advisory Claude effort.
- Added a conservative installer and validated progress import for existing implementations.
- Kept prompt IDs, technical requirements, architecture and configuration examples compatible.
- Rebuilt combined prompts, index, tracker view and distribution hashes.

This remains an implementation pack. Application runtime and production verification are
still carried out by its prompts. No application is declared complete by repackaging.
