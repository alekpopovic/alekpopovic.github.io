# First prompt for Claude Code

You are implementing Nginx Guard in this application repository. Inspect root CLAUDE.md,
any existing AGENTS.md, Git status and existing application code. Read
`docs/claude-pack/CLAUDE.md`, `docs/claude-pack/START_HERE.md` and the pack's
architecture, protocol, Nginx integration and security documents. Keep the specified stack.

Run `python3 docs/claude-pack/tools/track.py next`. Read that individual prompt and
`docs/claude-pack/prompts/COMMON.md`. Check the handoff and prior evidence against the
actual code. If progress was imported, do not reset or blindly repeat completed work.

Execute the selected task. Make a brief implementation plan when needed, then implement
working code and run the relevant checks. Keep standard Nginx OSS support and local-only
request checks. Follow normal client permissions; do not change them or model settings.
Do not stop after giving a plan when implementation is possible.

Record actual results in `docs/evidence/NNN.md`, update tracker and handoff, and report
the outcome, verification, limits and next task. Execute one prompt in this run unless the
user explicitly asks for a bounded phase. If blocked, explain the concrete dependency.
