# Resume Claude Code after interruption or context compaction

Read root CLAUDE.md, any AGENTS.md, Git status, `docs/claude-pack/tracking/state.json`
and `docs/claude-pack/tracking/HANDOFF.md`. Inspect actual modified files and the latest
relevant evidence before trusting a progress label or previous session summary.

Use `python3 docs/claude-pack/tools/track.py next` to resume the first incomplete task.
Read only its prompt, the common contract and relevant specs. Preserve unrelated work,
existing application code and imported completion history. Do not reset progress or rebuild
the project from scratch. Resolve any implementation/specification discrepancy explicitly.

Continue implementation and relevant checks; record results and update tracking. If a former
check is no longer supported by the code, reopen the affected task using the tracker's
documented workflow. End with the concrete outcome, limits and next action.
