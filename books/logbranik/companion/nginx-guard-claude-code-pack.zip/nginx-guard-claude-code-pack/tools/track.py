#!/usr/bin/env python3
"""Single-writer prompt tracker. It never executes prompts or changes model settings."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import sys
import tempfile

PACK = Path(__file__).resolve().parents[1]
STATE = PACK / 'tracking/state.json'
STATUSES = ('pending', 'in_progress', 'blocked', 'done')

def atomic_text(path: Path, text: str) -> None:
    fd, name = tempfile.mkstemp(prefix='.' + path.name, dir=path.parent)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as handle:
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(name, path)
    finally:
        if os.path.exists(name):
            os.unlink(name)

def read_state() -> dict:
    return json.loads(STATE.read_text(encoding='utf-8'))

def render(data: dict) -> str:
    counts = {s: sum(p['status'] == s for p in data['prompts']) for s in STATUSES}
    lines = ['# Execution progress', '',
             f"Done: {counts['done']}/{len(data['prompts'])}; in progress: {counts['in_progress']}; "
             f"blocked: {counts['blocked']}; pending: {counts['pending']}.", '',
             'Generated from state.json. Evidence paths are relative to the application repository.', '',
             '| ID | Task | Effort | Status | Evidence |', '|---|---|---|---|---|']
    for p in data['prompts']:
        evidence = (p.get('evidence') or '').replace('|', '\\|').replace('\n', ' ')
        lines.append(f"| {p['id']} | {p['title']} | {p['effort']} | {p['status']} | {evidence} |")
    return '\n'.join(lines) + '\n'

def save(data: dict) -> None:
    atomic_text(STATE, json.dumps(data, indent=2, ensure_ascii=False) + '\n')
    atomic_text(PACK / 'tracking/PROGRESS.md', render(data))

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    sub.add_parser('status')
    sub.add_parser('next')
    sub.add_parser('render')
    show = sub.add_parser('show'); show.add_argument('id')
    change = sub.add_parser('set')
    change.add_argument('id'); change.add_argument('status', choices=STATUSES)
    change.add_argument('--evidence', help='Existing nonempty evidence path relative to the current working directory (application repo)')
    change.add_argument('--note', default='')
    change.add_argument('--reopen', action='store_true', help='Reopen completed work and invalidate all downstream completion states')
    args = parser.parse_args()
    data = read_state(); prompts = data['prompts']
    if args.command == 'status':
        for status in STATUSES:
            print(f'{status}: {sum(p["status"] == status for p in prompts)}')
        return 0
    if args.command == 'next':
        item = next((p for p in prompts if p['status'] != 'done'), None)
        if item is None:
            print('All prompts marked done. Review FINAL_REPORT and evidence before release.')
        else:
            print(f"{item['id']} [{item['status']}] {item['title']}\n{PACK / item['prompt']}")
        return 0
    if args.command == 'render':
        atomic_text(PACK / 'tracking/PROGRESS.md', render(data))
        print('Rendered tracking/PROGRESS.md')
        return 0
    if not args.id.isdigit():
        parser.error('Prompt ID must be numeric.')
    pid = f'{int(args.id):03d}'
    item = next((p for p in prompts if p['id'] == pid), None)
    if item is None:
        parser.error(f'Unknown prompt: {pid}')
    if args.command == 'show':
        print((PACK / item['prompt']).read_text(encoding='utf-8'))
        return 0
    idx = prompts.index(item)
    if args.reopen and (item['status'] != 'done' or args.status == 'done'):
        parser.error('--reopen requires a completed prompt and a new non-done status.')
    if item['status'] == 'done' and args.status != 'done' and not args.reopen:
        parser.error('Use --reopen to invalidate this and downstream completed work.')
    if args.status in ('in_progress', 'done'):
        missing = [p['id'] for p in prompts[:idx] if p['status'] != 'done']
        if missing:
            parser.error('Incomplete earlier prompts: ' + ', '.join(missing))
    if args.status == 'in_progress':
        active = [p['id'] for p in prompts if p['id'] != pid and p['status'] == 'in_progress']
        if active and not args.reopen:
            parser.error('Another prompt is in progress: ' + ', '.join(active))
    if args.status == 'done':
        if not args.evidence:
            parser.error('done requires --evidence with a nonempty local evidence file.')
        evidence = Path(args.evidence).expanduser()
        if not evidence.is_file() or not evidence.read_text(encoding='utf-8').strip():
            parser.error('Evidence file is missing or empty. Run from the application repository.')
    now = datetime.now(timezone.utc).isoformat()
    if args.reopen:
        data.setdefault('history', []).append({'at': now, 'action': 'reopen', 'id': pid,
                                             'prior': [dict(p) for p in prompts[idx:]]})
        for later in prompts[idx + 1:]:
            later.update(status='pending', evidence=None, updated_at=now,
                         notes=f'Invalidated by reopening {pid}; revalidate before completion.')
    item.update(status=args.status, updated_at=now, notes=args.note,
                evidence=args.evidence if args.status == 'done' else None)
    save(data)
    print(f"{pid}: {args.status}")
    return 0

if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (OSError, ValueError, KeyError) as exc:
        print(f'Tracker error: {exc}', file=sys.stderr)
        raise SystemExit(1)
