#!/usr/bin/env python3
"""Import compatible prior progress into a pristine Claude tracker; never execute tasks."""
from __future__ import annotations
import argparse
import copy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys

sys.dont_write_bytecode=True
from track import PACK, STATE, STATUSES, read_state, save

def main() -> int:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source',required=True,type=Path)
    parser.add_argument('--dry-run',action='store_true')
    args=parser.parse_args()
    source=args.source.expanduser().resolve()
    if source==STATE.resolve(): parser.error('Source must be a different tracker.')
    source_bytes=source.read_bytes()
    old=json.loads(source_bytes)
    current=read_state()
    if old.get('schema_version') not in (1,2): parser.error('Unsupported source schema.')
    if old.get('project')!=current['project']: parser.error('Project mismatch.')
    before=old.get('prompts')
    after=current['prompts']
    if not isinstance(before,list) or len(before)!=len(after): parser.error('Prompt count mismatch.')
    if any(p['status']!='pending' or p.get('evidence') or p.get('notes') or p.get('updated_at') for p in after) or current.get('history'):
        parser.error('Import only into a pristine pending tracker; existing progress was not overwritten.')
    if sum(p.get('status')=='in_progress' for p in before)>1: parser.error('Multiple in-progress tasks in source.')
    imported=copy.deepcopy(current)
    for i,(src,dst) in enumerate(zip(before,imported['prompts'])):
        if src.get('id')!=dst['id'] or src.get('title')!=dst['title']: parser.error(f'Prompt identity mismatch at row {i}.')
        if src.get('depends_on')!=dst['depends_on']: parser.error(f'Dependency mismatch at {dst["id"]}.')
        status=src.get('status')
        if status not in STATUSES: parser.error(f'Invalid status at {dst["id"]}.')
        if status in ('in_progress','done') and any(p.get('status')!='done' for p in before[:i]):
            parser.error(f'Unfinished prerequisite for {dst["id"]}.')
        evidence=src.get('evidence')
        if status=='done':
            if not isinstance(evidence,str) or not evidence: parser.error(f'Missing evidence for {dst["id"]}.')
            evidence_file=Path(evidence).expanduser()
            if not evidence_file.is_file() or not evidence_file.read_text(encoding='utf-8').strip():
                parser.error(f'Evidence missing/empty for {dst["id"]}: {evidence}. Run from the application repo.')
        for key in ('notes','updated_at'):
            if src.get(key) is not None and not isinstance(src[key],str): parser.error(f'Invalid {key} at {dst["id"]}.')
        dst.update(status=status,evidence=evidence,notes=src.get('notes') or '',updated_at=src.get('updated_at'))
    done=sum(p['status']=='done' for p in before)
    print(f'Compatible import: {done}/60 done; original paths and metadata in the new edition retained.')
    if args.dry_run:
        print('Dry run: no files changed.')
        return 0
    now=datetime.now(timezone.utc)
    backup=PACK/'tracking'/f'state-before-import-{now.strftime("%Y%m%dT%H%M%S%fZ")}.json'
    with backup.open('xb') as f: f.write(STATE.read_bytes())
    imported.setdefault('history',[]).append({
        'at':now.isoformat(),'action':'import_progress','source':str(source),
        'source_sha256':hashlib.sha256(source_bytes).hexdigest(),
        'source_pack_version':old.get('pack_version'),'source_history':old.get('history',[])
    })
    save(imported)
    print('Imported statuses and regenerated PROGRESS.md. Review the previous handoff and use RESUME_PROMPT.md.')
    return 0

if __name__=='__main__':
    try: raise SystemExit(main())
    except (OSError,ValueError,KeyError,TypeError) as exc:
        print(f'Import error: {exc}',file=sys.stderr)
        raise SystemExit(1)
