#!/usr/bin/env python3
"""Validate prompt-pack structure, not the future application runtime."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import sys
import tomllib

PACK = Path(__file__).resolve().parents[1]

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check-hashes', action='store_true', help='Check pristine distribution files; tracker edits intentionally change hashes')
    args = parser.parse_args()
    data = json.loads((PACK/'tracking/state.json').read_text())
    assert data['schema_version'] == 2, 'Expected Claude tracker schema 2'
    assert data['edition'] == 'claude-code'
    entries = data['prompts']
    assert len(entries) == 60, 'Expected 60 prompts'
    assert [e['id'] for e in entries] == [f'{n:03d}' for n in range(60)]
    prompt_files = sorted((PACK/'prompts').glob('[0-9][0-9][0-9]-*.md'))
    assert len(prompt_files) == 60
    all_prompts = (PACK/'ALL_PROMPTS.md').read_text()
    titles = set()
    for n, e in enumerate(entries):
        path = PACK/e['prompt']
        assert path.is_file(), f'Missing {path}'
        assert e['title'] not in titles, 'Duplicate title'
        titles.add(e['title'])
        assert e['depends_on'] == ([] if n == 0 else [f'{n-1:03d}'])
        assert e['status'] in ('pending','in_progress','blocked','done')
        assert e['effort'] in ('medium','high','xhigh')
        content = path.read_text().strip()
        assert content in all_prompts, f'Consolidated text mismatch {e["id"]}'
        for section in ('## Task','## Expected deliverables','## Acceptance and verification','## Completion record'):
            assert section in content, f'Missing section {e["id"]}: {section}'
        assert len(content.split()) >= 190, f'Underspecified prompt {e["id"]}'
        assert 'Recommended Claude effort:' in content
        assert 'docs/codex-pack' not in content
        assert '## Claude execution notes' in content
        if e['status'] == 'done':
            assert e['evidence'], f'Missing evidence reference for {e["id"]}'
            assert all(p['status']=='done' for p in entries[:n])
    assert sum(e['status']=='in_progress' for e in entries) <= 1
    for path in PACK.rglob('*.json'):
        json.loads(path.read_text())
    for line in (PACK/'examples/contracts/event.ndjson').read_text().splitlines():
        json.loads(line)
    tomllib.loads((PACK/'examples/vector/vector.toml.example').read_text())
    for required in ('CLAUDE.md','templates/CLAUDE.project-template.md',
                     'BOOTSTRAP_PROMPT.md','RESUME_PROMPT.md','RUN_NEXT_PROMPT.md',
                     'RUN_PHASE_PROMPT.md','CHECKPOINT_PROMPT.md','docs/CLAUDE_CODE_GUIDE.md',
                     'tools/install_pack.py','tools/import_progress.py'):
        assert (PACK/required).is_file(), f'Missing Claude entrypoint: {required}'
    assert '@docs/claude-pack/CLAUDE.md' in (PACK/'templates/CLAUDE.project-template.md').read_text()
    # Validate actual relative Markdown links; inline code paths are task instructions.
    for md in PACK.rglob('*.md'):
        for ref in re.findall(r'(?<!!)\[[^\]]+\]\(([^)]+)\)', md.read_text()):
            if ref.startswith(('https://','http://','#','mailto:')):
                continue
            target = (md.parent/ref.split('#')[0]).resolve()
            assert target.exists(), f'Broken link in {md.name}: {ref}'
    if args.check_hashes:
        for line in (PACK/'SHA256SUMS').read_text().splitlines():
            digest, name = line.split('  ',1)
            assert hashlib.sha256((PACK/name).read_bytes()).hexdigest() == digest, f'Hash mismatch: {name}'
    print(f'PASS: 60 numbered prompts, dependency order, consolidated text, JSON, TOML syntax and Markdown links.')
    print('Nginx/Vector runtime and application tests are not covered by this validator.')

if __name__ == '__main__':
    try:
        main()
    except (AssertionError, OSError, ValueError, KeyError) as exc:
        print(f'FAIL: {exc}', file=sys.stderr)
        sys.exit(1)
