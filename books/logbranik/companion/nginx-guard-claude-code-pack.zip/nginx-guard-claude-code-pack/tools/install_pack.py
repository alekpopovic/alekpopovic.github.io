#!/usr/bin/env python3
"""Install this pack into an existing repository without overwriting project instructions."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import os
from pathlib import Path
import shutil
import sys
import tempfile

PACK = Path(__file__).resolve().parents[1]
IMPORT = '@docs/claude-pack/CLAUDE.md'

def main() -> int:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo',required=True,type=Path)
    parser.add_argument('--dry-run',action='store_true')
    args=parser.parse_args()
    repo=args.repo.expanduser().resolve()
    if not repo.is_dir(): parser.error('The repository directory must already exist.')
    target=repo/'docs/claude-pack'
    root_instructions=repo/'CLAUDE.md'
    if target.is_relative_to(PACK): parser.error('Choose an application repository outside the extracted pack.')
    if (repo/'docs').is_symlink(): parser.error('The repository docs directory must not be a symlink.')
    if (repo/'docs').exists() and not (repo/'docs').is_dir(): parser.error('docs exists but is not a directory.')
    if target.exists() or target.is_symlink(): parser.error('docs/claude-pack already exists; it was not overwritten.')
    if root_instructions.is_symlink(): parser.error('CLAUDE.md is a symlink; merge the import manually.')
    if root_instructions.exists() and not root_instructions.is_file(): parser.error('CLAUDE.md is not a regular file.')
    old=root_instructions.read_bytes() if root_instructions.exists() else None
    if old is None:
        new=(PACK/'templates/CLAUDE.project-template.md').read_bytes()
    elif IMPORT in old.decode('utf-8').splitlines():
        new=old
    else:
        new=old+b'\n\n## Nginx Guard implementation pack\n\n'+IMPORT.encode()+b'\n'
    print(f'Pack destination: {target}')
    print('Root CLAUDE.md: '+('create' if old is None else 'preserve; append import and create backup' if new!=old else 'preserve existing import'))
    if args.dry_run:
        print('Dry run: no files changed.')
        return 0
    target.parent.mkdir(parents=True,exist_ok=True)
    staging=Path(tempfile.mkdtemp(prefix='.claude-pack-stage-',dir=target.parent))
    published=False
    try:
        shutil.copytree(PACK,staging/'pack',ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
        if old is not None and new!=old:
            stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
            backups=repo/'docs/claude-pack-install-backups'
            if backups.is_symlink(): raise ValueError('Backup directory must not be a symlink.')
            backups.mkdir(exist_ok=True)
            with (backups/f'CLAUDE-{stamp}.md').open('xb') as f: f.write(old)
        if target.exists(): raise ValueError('Destination appeared during installation; aborting.')
        os.rename(staging/'pack',target)
        published=True
        if new!=old:
            temp=staging/'CLAUDE.md'
            temp.write_bytes(new)
            if old is not None: shutil.copymode(root_instructions,temp)
            os.replace(temp,root_instructions)
    except Exception:
        # A published pack is valid; report partial instruction setup rather than deleting work.
        if published: print('Pack copied; root instruction setup may be incomplete. Inspect CLAUDE.md.',file=sys.stderr)
        raise
    finally:
        shutil.rmtree(staging)
    print('Installed. Open Claude Code at the application repository root and use BOOTSTRAP_PROMPT.md.')
    return 0

if __name__=='__main__':
    try: raise SystemExit(main())
    except (OSError,ValueError) as exc:
        print(f'Install error: {exc}',file=sys.stderr)
        raise SystemExit(1)
