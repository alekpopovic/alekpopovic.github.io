# Claude Code prompt index

Run in ascending order. All entries start pending; import prior progress if applicable. Effort is advisory.

| ID | Phase | Title | Effort |
|---|---|---|---|
| 000 | Foundation | [Repository inventory and project bootstrap](prompts/000-repository-inventory-and-project-bootstrap.md) | high |
| 001 | Foundation | [Version selection and reproducible dependencies](prompts/001-version-selection-and-reproducible-dependencies.md) | high |
| 002 | Foundation | [Typed contracts and golden fixtures](prompts/002-typed-contracts-and-golden-fixtures.md) | high |
| 003 | Foundation | [Local networks and development certificates](prompts/003-local-networks-and-development-certificates.md) | high |
| 004 | Foundation | [Database schema and initial migrations](prompts/004-database-schema-and-initial-migrations.md) | high |
| 005 | Foundation | [Build commands and test foundation](prompts/005-build-commands-and-test-foundation.md) | medium |
| 006 | Log ingestion | [Authenticated central service and role boundaries](prompts/006-authenticated-central-service-and-role-boundaries.md) | xhigh |
| 007 | Log ingestion | [Bounded NDJSON ingestion](prompts/007-bounded-ndjson-ingestion.md) | high |
| 008 | Log ingestion | [Deduplication and durable processing queue](prompts/008-deduplication-and-durable-processing-queue.md) | xhigh |
| 009 | Log ingestion | [Structured Nginx access logging](prompts/009-structured-nginx-access-logging.md) | high |
| 010 | Log ingestion | [Vector transport and disk buffering](prompts/010-vector-transport-and-disk-buffering.md) | high |
| 011 | Log ingestion | [First complete log ingestion demonstration](prompts/011-first-complete-log-ingestion-demonstration.md) | high |
| 012 | Local enforcement | [Go agent process and local listener](prompts/012-go-agent-process-and-local-listener.md) | high |
| 013 | Local enforcement | [Immutable policy state and atomic persistence](prompts/013-immutable-policy-state-and-atomic-persistence.md) | xhigh |
| 014 | Local enforcement | [Local authorization decision engine](prompts/014-local-authorization-decision-engine.md) | high |
| 015 | Local enforcement | [Nginx auth_request integration](prompts/015-nginx-auth-request-integration.md) | xhigh |
| 016 | Local enforcement | [Availability profiles and local emergency bypass](prompts/016-availability-profiles-and-local-emergency-bypass.md) | xhigh |
| 017 | Local enforcement | [Local expiry and offline enforcement milestone](prompts/017-local-expiry-and-offline-enforcement-milestone.md) | high |
| 018 | Secure synchronization | [Ed25519 signatures and cross-language vectors](prompts/018-ed25519-signatures-and-cross-language-vectors.md) | xhigh |
| 019 | Secure synchronization | [Private mTLS snapshot receiver](prompts/019-private-mtls-snapshot-receiver.md) | xhigh |
| 020 | Secure synchronization | [Desired decisions and transactional snapshot outbox](prompts/020-desired-decisions-and-transactional-snapshot-outbox.md) | xhigh |
| 021 | Secure synchronization | [Reliable push delivery and applied acknowledgements](prompts/021-reliable-push-delivery-and-applied-acknowledgements.md) | high |
| 022 | Secure synchronization | [Pull reconciliation and node heartbeat](prompts/022-pull-reconciliation-and-node-heartbeat.md) | high |
| 023 | Secure synchronization | [Manual block lifecycle end-to-end milestone](prompts/023-manual-block-lifecycle-end-to-end-milestone.md) | high |
| 024 | Detection | [Event-time aggregation and concurrency correctness](prompts/024-event-time-aggregation-and-concurrency-correctness.md) | xhigh |
| 025 | Detection | [Sensitive-path scanning rules](prompts/025-sensitive-path-scanning-rules.md) | high |
| 026 | Detection | [Login-abuse rule with explicit endpoint semantics](prompts/026-login-abuse-rule-with-explicit-endpoint-semantics.md) | high |
| 027 | Detection | [Request-volume and error anomaly monitoring](prompts/027-request-volume-and-error-anomaly-monitoring.md) | high |
| 028 | Detection | [Risk policy and safe automatic decision creation](prompts/028-risk-policy-and-safe-automatic-decision-creation.md) | xhigh |
| 029 | Detection | [Automatic detection-to-block demonstration](prompts/029-automatic-detection-to-block-demonstration.md) | high |
| 030 | Operations controls | [Operator roles and complete audit trail](prompts/030-operator-roles-and-complete-audit-trail.md) | high |
| 031 | Operations controls | [Operator CLI for investigation](prompts/031-operator-cli-for-investigation.md) | medium |
| 032 | Operations controls | [Operator CLI for bounded policy changes](prompts/032-operator-cli-for-bounded-policy-changes.md) | high |
| 033 | Operations controls | [Allowlist precedence and revocation race handling](prompts/033-allowlist-precedence-and-revocation-race-handling.md) | xhigh |
| 034 | Operations controls | [Evidence search and decision explanations](prompts/034-evidence-search-and-decision-explanations.md) | medium |
| 035 | Operations controls | [False-positive recovery and emergency drills](prompts/035-false-positive-recovery-and-emergency-drills.md) | high |
| 036 | Fleet and observability | [Fleet membership and multiple sites per node](prompts/036-fleet-membership-and-multiple-sites-per-node.md) | high |
| 037 | Fleet and observability | [Snapshot coalescing and bounded delivery scaling](prompts/037-snapshot-coalescing-and-bounded-delivery-scaling.md) | high |
| 038 | Fleet and observability | [Raw-event retention and database maintenance](prompts/038-raw-event-retention-and-database-maintenance.md) | high |
| 039 | Fleet and observability | [Metrics and structured cross-service diagnostics](prompts/039-metrics-and-structured-cross-service-diagnostics.md) | high |
| 040 | Fleet and observability | [Alert rules and operational health views](prompts/040-alert-rules-and-operational-health-views.md) | medium |
| 041 | Fleet and observability | [Measured throughput and latency baseline](prompts/041-measured-throughput-and-latency-baseline.md) | high |
| 042 | Failure validation | [Central outages, backpressure and collector recovery](prompts/042-central-outages-backpressure-and-collector-recovery.md) | high |
| 043 | Failure validation | [Clock, TTL and restart fault matrix](prompts/043-clock-ttl-and-restart-fault-matrix.md) | xhigh |
| 044 | Failure validation | [TLS and signing-key lifecycle](prompts/044-tls-and-signing-key-lifecycle.md) | xhigh |
| 045 | Failure validation | [Hostile inputs and cross-scope security tests](prompts/045-hostile-inputs-and-cross-scope-security-tests.md) | xhigh |
| 046 | Failure validation | [Nginx routing and existing-auth regression suite](prompts/046-nginx-routing-and-existing-auth-regression-suite.md) | xhigh |
| 047 | Failure validation | [Complete reliability regression gate](prompts/047-complete-reliability-regression-gate.md) | high |
| 048 | Deployment | [Production images and agent release binaries](prompts/048-production-images-and-agent-release-binaries.md) | high |
| 049 | Deployment | [Hardened systemd units and filesystem ownership](prompts/049-hardened-systemd-units-and-filesystem-ownership.md) | high |
| 050 | Deployment | [Idempotent installation and canary configuration](prompts/050-idempotent-installation-and-canary-configuration.md) | high |
| 051 | Deployment | [Database backup and tested restore](prompts/051-database-backup-and-tested-restore.md) | xhigh |
| 052 | Deployment | [Upgrade, rollback and compatibility procedures](prompts/052-upgrade-rollback-and-compatibility-procedures.md) | high |
| 053 | Deployment | [Deployment observability and recovery handbook](prompts/053-deployment-observability-and-recovery-handbook.md) | medium |
| 054 | Release | [Continuous integration and release policy](prompts/054-continuous-integration-and-release-policy.md) | high |
| 055 | Release | [Replay evaluation and production threshold calibration](prompts/055-replay-evaluation-and-production-threshold-calibration.md) | high |
| 056 | Release | [Monitor-only installation readiness](prompts/056-monitor-only-installation-readiness.md) | high |
| 057 | Release | [Single-site enforcement canary](prompts/057-single-site-enforcement-canary.md) | high |
| 058 | Release | [Staged fleet enablement and rollback drill](prompts/058-staged-fleet-enablement-and-rollback-drill.md) | high |
| 059 | Release | [Final audit and release handoff](prompts/059-final-audit-and-release-handoff.md) | xhigh |
