# Nginx Guard

Follow existing repository conventions and explicitly inspect AGENTS.md if it exists.
The implementation pack's shared rules are imported below.

@docs/claude-pack/CLAUDE.md

Keep this file concise. Current progress belongs in the pack's tracking files, not repeated
copies of completed task history here. Merge with an existing CLAUDE.md instead of replacing it.
