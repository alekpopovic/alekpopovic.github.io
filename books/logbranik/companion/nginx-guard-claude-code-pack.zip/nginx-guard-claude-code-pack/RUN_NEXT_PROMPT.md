# Execute the next task

Read project CLAUDE.md, `docs/claude-pack/tracking/state.json`, the handoff and Git status.
Run `python3 docs/claude-pack/tools/track.py next`. Read that individual prompt and the
common execution contract, then implement it through its acceptance checks. If the task is
already in_progress or blocked, resolve that task before starting a later one. Record actual
evidence, update tracker and handoff, and stop at this task's completion with a concise report.
