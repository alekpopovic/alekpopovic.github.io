# Claude edition validation — 2026-10-10

This is an implementation pack. Repackaging does not mark application tasks complete.

Executed checks for this edition:

- 60 consecutive prompt IDs, unique titles, ordered dependencies and Claude effort metadata.
- All individual prompt texts match ALL_PROMPTS.md; index links and native entrypoint paths resolve.
- Technical architecture/protocol documents are byte-identical to the source edition;
  all task acceptance criteria are preserved, with only the pack directory reference changed.
- JSON and NDJSON parse, Vector reference TOML parses, and all Python tools parse.
- Installation into a fresh temporary repository creates the expected CLAUDE.md import.
- Existing project instructions and AGENTS.md are retained; append operations create a backup.
- Installer dry-run leaves the repository untouched; an existing installed pack is not overwritten.
- Progress-import dry-run makes no edits. Real import retains statuses, evidence, notes,
  timestamps and history while keeping the new edition's instruction paths and metadata.
- Missing evidence, task mismatches and attempts to overwrite non-pristine progress are rejected.
- Tracker prerequisite/evidence gates, reopening, downstream invalidation and rendering work.
- The distributed tracker remains pending for all 60 tasks.
- SHA256SUMS and ZIP CRC are verified during final packaging.

Not executed as part of package conversion: Claude Code client sessions, actual Nginx/Vector
runtime validation, the future FastAPI/Go application, load/security integration tests or a live
deployment. Runtime validation remains explicitly assigned to the implementation prompts.
Claude-specific instruction/import/effort guidance was checked against official documentation;
the local installer and tracking tools were exercised in disposable repositories.

For a pristine extracted distribution, run:

```bash
python3 tools/validate_pack.py --check-hashes
python3 tools/track.py status
```

Use Python 3.11+. After updating the tracker, run validate_pack.py without --check-hashes,
because the distribution hashes intentionally no longer match modified tracking files.
