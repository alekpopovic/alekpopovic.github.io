# Save a checkpoint before ending a session

Inspect the current diff and task status. Update `docs/claude-pack/tracking/HANDOFF.md`
with current prompt ID, actual repo/branch, edited files, completed behavior, exact checks
and outcomes, unverified items, blockers and the next command/action. Keep incomplete work
in_progress or blocked. Link evidence; do not embed secrets or a full conversation transcript.
Do not commit or push solely to make a checkpoint. Summarize where to resume.
