# Nginx Guard — Claude Code project contract

This pack belongs at `docs/claude-pack/` in the application repository. Run application
commands from the repository root. The root CLAUDE.md should import this file; the
installer adds that import without replacing existing instructions.

## Required context

Inspect the repository's CLAUDE.md and any existing AGENTS.md explicitly. Preserve existing
project rules and unrelated changes. Read `docs/claude-pack/tracking/state.json`,
`tracking/HANDOFF.md` in the pack and current Git status before choosing work.
Use `python3 docs/claude-pack/tools/track.py next` to identify the first incomplete task.

Read `prompts/COMMON.md` and that task's individual Markdown file in the pack. Consult
`docs/ARCHITECTURE.md`, `docs/CONTRACTS.md`, `docs/NGINX_INTEGRATION.md`,
`docs/SECURITY.md` and task-specific acceptance cases as needed. Do not load
ALL_PROMPTS.md into every session: it is an export for manual reference.

## Fixed implementation constraints

- Nginx Open Source, Vector, FastAPI, PostgreSQL and Go edge agent.
- No remote request-time check: local Unix socket plus in-memory policy only.
- Automatic bans are site-scoped exact IPs with TTL; new sites start monitor-only.
- Signed mTLS control snapshots, durable revisions, audited changes and replay protection.
- No Nginx reload for each ban, Redis, Kafka, Kubernetes, Nginx Plus, Lua or AI detector.
- The existing application authentication remains effective during any Guard fail-open mode.

## Work and completion

Execute one numbered task at a time. If the user explicitly chooses a bounded phase,
complete its tasks sequentially and update evidence after each one. Plan briefly when useful,
then implement; a planning response is not task completion. If the client is in a read-only
planning mode, report that mode rather than claiming implementation.

Use the installed environment's actual commands. Do not change model or permission settings
silently. Normal local work follows the user's authorization and client permissions; production
operations require target-specific authorization. Do not bypass safeguards to continue.

Write real command results and limitations to `docs/evidence/NNN.md`, then update state
using the tracker. A `done` label requires actual acceptance evidence. Keep one tracker writer.
Before context compaction or ending a session, update the handoff with the precise next action.
Ask only when a missing fact blocks the work; continue independent authorized work meanwhile.
Do not create or push commits just to fill the tracker unless the user requests that workflow.

Effort metadata is advisory and does not change Claude settings. Summarize implemented
behavior, checks, remaining blockers and next task. Keep design changes explicit.
